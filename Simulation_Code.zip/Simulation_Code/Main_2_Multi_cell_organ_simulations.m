%% For simulations of different mutants and treatments
%% Biological parameters used in 3D organ model
clc
clear
load('R0_Parameter.mat') % Load cell positions and interaction in 3D organ

% Calculate numbers of neighbors for each cell
parameter.Neighbor_Num = sum(parameter.interaction_M_M,2);
parameter.Neighbor_Num = parameter.Neighbor_Num(parameter.out_or_not==0);
parameter.Inner_Neighbor_Num = sum(parameter.interaction_M,2);
parameter.Inner_Neighbor_Num(:,2) = parameter.Neighbor_Num;

% parameters fixed
parameter.h = 2;                    % hill coefficience of [NICD] --> Hes1
parameter.h0 = 2;                   % hill coefficience of Hes1 --> Ptf1a
parameter.h1 = 2;                   % hill coefficience of Ptf1a --> Delta/Jag1

load('ball_color_brown.mat')
parameter.ball_color_brown = x;

load('ball_color_green.mat')
parameter.ball_color_green = x;

load('ball_color_red.mat')
parameter.ball_color_red = x;

parameter.fate_colors = [0.2,0.7,0;0.6,0.5,0.3;0.7,0.2,0];

parameter.tspan = [0,3600];
parameter.options = ddeset('RelTol',1e-4);
history_Z = repmat(0.1*ones(5,1),1,parameter.N);
history_Z = history_Z';
parameter.history_Z = history_Z(:);
parameter.var_num = 5;              % number of variables

% parameters for wildtype
parameter.a_H = 3;                  % max production rate of Hes1 
parameter.a_D = 0.5;                % max production rate of Dll1 by Hes1
parameter.a_J = 1.0;                % max production rate of Jag1 
parameter.a_w = 0.8;                % max production rate of Dll1 by Ptf1a
parameter.a_N = 0.5;                % max production rate of Notch
parameter.a_P = 0.2;                % max production rate of Ptf1a

parameter.tau_0 = [40,0.1];         % time delay of Hes1, Dll1; 0.1 means no time delay in Dll1 transcription

hr = 1;%/log(2);
parameter.tau_h = 20*hr;               % decay time of Hes1
parameter.tau_d = 50*hr;               % decay time of Dll1
parameter.tau_j = 120*hr;              % decay time of Jag1
parameter.tau_n = 50*hr;               % decay time of Notch
parameter.tau_p = 120*hr;              % decay time of Ptf1a
               
% for Dll1
parameter.r11 = 0.25;                 % rate parameter for cis
parameter.r21 = 0.02;                 % rate parameter for trans              

% for Jag1
parameter.r12 = 0.25;                 % rate parameter for cis
parameter.r22 = 0.02;                % rate parameter for trans              

parameter.K1 = 0.3;                 % Hes1 --| Hes1
parameter.K2 = 0.06;                % [NICD] --> Hes1
parameter.K3 = 0.8;                 % Hes1 --| Dll1
parameter.K4 = 4;                   % Ptf1a -->Jag1 
parameter.K6 = 4;                   % Ptf1a -->Dll1 
parameter.K5 = 0.1;                 % Hes1 --| Ptf1a

save R1_Parameter parameter
% Different mutants and treatments
close all
for caseID = 1:1
    caseID
    load('R1_Parameter.mat')
    %parameter.options = ddeset('RelTol',1e-2);
    switch caseID
        case 1
            title_str = 'Wildtype';
        case 2
            title_str = 'Dll1 deficient';
            parameter.a_D = 0;parameter.a_w = 0;    
        case 3
            title_str = 'Jag1 deficient';
            parameter.a_J = 0;
        case 4
            title_str = 'DAPT';
            parameter.K2 = 0.3;
        case 5
            title_str = 'MLN4924';
            parameter.K2 = 0.01;
        case 6
            title_str = 'Dll1 delay';
            parameter.tau_0(2) = 6;% or 6
        case 7
            title_str = 'Dll1 delay wo Jag1';
            parameter.a_J = 0;
            parameter.tau_0(2) = 6; 
        case 8
            dd = 0.5;
            title_str = 'Slow Ptf1a';
            parameter.tau_p = parameter.tau_p/dd;
            parameter.a_P = parameter.a_P*dd;
        case 9
            dd = 2;
            title_str = 'Fast Ptf1a';
            parameter.tau_p = parameter.tau_p/dd;
            parameter.a_P = parameter.a_P*dd; 
         case 10
            dd = 50;
            title_str = 'superFast Ptf1a';
            parameter.tau_p = parameter.tau_p/dd;
            parameter.a_P = parameter.a_P*dd;
        case 11
            title_str = 'Remove Cis_Dll1';
            parameter.r11 = 0;            
        case 12
            title_str = 'Remove Trans_Dll1';
            parameter.r21 = 0;  
        case 13
            title_str = 'Remove Cis_Jag1';
            parameter.r12 = 0;
        case 14
             title_str = 'Remove Trans_Jag1';
             parameter.r22 = 0;
        case 15
             title_str = 'Fixed nei_num';
             Restrict = 12;
             parameter.K2 = 0.1;
             interaction_M = zeros(parameter.N,parameter.N);
             R_ij = pdist2(parameter.cell_center,parameter.cell_center);
             for i = 1:parameter.N
                  [~,I] = sort(R_ij(i,:));
                  nei_k = I(1:Restrict);
                  if ismember(i,nei_k)
                     nei_k(nei_k==i) = I(Restrict+1);
                  end
                  interaction_M(i,nei_k) = 1;
                  parameter.Neighbor_Num(i) = Restrict;
                  parameter.Inner_Neighbor_Num(i,1:2) = [Restrict, Restrict];
                  rng(0)
                  history_Z = parameter.history_Z.*(1+0.1*rand(length(parameter.history_Z),1));
                  parameter.history_Z = history_Z;
             end    
             parameter.interaction_M = interaction_M;
        case 16
            % Partially delete of Dll1
            title_str = 'Dll1 Partial_deficient';
            parameter.a_D = 0.5*parameter.a_D;parameter.a_w = 0.5*parameter.a_w;  
            
        case 17
            % Partially delete of Jag1
            title_str = 'Jag1 Partial_deficient';
            parameter.a_J = 0.5*parameter.a_J;  
        case 18
            title_str =  'Large_tau_n_MLN4924';
            parameter.tau_n = 500;
        case 19
            % different cis for Dll1 and Jag1
            parameter.r11 = 0.25; 
            parameter.r12 = 0.15;
             parameter.a_D = 0; parameter.a_w = 0;
%             parameter.a_J = 0;
            title_str = 'Diff_cis';
            
    end
    

Plot_N = 1; 
sol = dde23(@(t,y,Z) Notch_Delta_Hes1_GRN_Hes1_Delta_Jag1_Notch(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);

sol.Statistic = Estimate_Hes1_AP_Ptf1a_Mean(sol, parameter,Plot_N);
S = calculate_Notch_signaling(sol,parameter);
sol.S = S;
save([title_str,'.mat'], 'sol')
cell_id = [115,109,95];
% cell_id = randperm(parameter.N,3)
Plot_Gene_Dynamic(sol, parameter, cell_id, [2500,3000],0)

Plot_Gene_Dynamic(sol, parameter, cell_id, [0,2000],0)

end

%%
Cell_Ident = [];
for i = 1:3
    if i == 1
        load('Wildtype.mat')
        Cell_Ident = sol.Statistic(:,4);
    end
    if i == 2
        load('Dll1 deficient.mat')
        Cell_Ident(:,2) = sol.Statistic(:,4);
    end
    if i == 3
        load('Jag1 deficient.mat')
        Cell_Ident(:,3) = sol.Statistic(:,4);
    end
    Scatter3DPlot(sol, parameter, []);

end

figure
imagesc(Cell_Ident)
colormap(parameter.fate_colors)

