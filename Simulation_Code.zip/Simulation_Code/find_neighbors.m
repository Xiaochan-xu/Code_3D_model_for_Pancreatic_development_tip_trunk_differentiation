function parameter = find_neighbors(parameter)
% this code is for finding neighbors

% find neighbors
interaction_M = zeros(parameter.N,parameter.N);
R_ij = pdist2(parameter.cell_center,parameter.cell_center);
for i = 1:parameter.N
    if parameter.N <= parameter.candidate_nei_num
       k = 1:parameter.N;
       k(i) = [];
    else
       [~,I] = sort(R_ij(i,:));
       k = I(2:parameter.candidate_nei_num);
    end
    % knnsearch
    candidate_nei = parameter.cell_center(k,:);
    mid_point = 0.5*[candidate_nei(:,1)+parameter.cell_center(i,1), candidate_nei(:,2)+parameter.cell_center(i,2), candidate_nei(:,3)+parameter.cell_center(i,3)];
    Idx = knnsearch(candidate_nei,mid_point);
    interaction_M(i,k(Idx == [1:length(k)]')) = 1;
end

% find cells on the sphere

k = convhulln(parameter.cell_center);
out_or_not = unique(k(:));
% add all neighbor
M = interaction_M(out_or_not,:);
H = find(any(M>0,1));
out_or_not = union(out_or_not,H);

parameter.out_or_not(out_or_not) = 1;
parameter.interaction_M = interaction_M;

end

