%% Codes for Figure.2 and suppFig.2
% Simulation of two-cell model with different cis and trans interaction
% strength, and time delay for Dll1 transcription

%% Parameters used

parameter.h = 2;                    % hill coefficience of [NICD] --> Hes1
parameter.h0 = 2;                   % hill coefficience of Hes1 --> Ptf1a
parameter.h1 = 2;                   % hill coefficience of Ptf1a --> Delta/Jag1
parameter.N = 2;
parameter.interaction_M = [0,1;1,0];
parameter.interaction_M_M = [0,1;1,0];
parameter.Neighbor_Num = [1;1];
parameter.Inner_Neighbor_Num = [1;1];
parameter.fate_colors = [0.2,0.7,0;0.6,0.5,0.3;0.7,0.2,0];
parameter.tspan = [0,3600];
parameter.options = ddeset('RelTol',1e-4);
history_Z = [0.5,0.6,1.1,1,0,0,1,1,0,0]; % Initial condition for the two cells
history_Z = history_Z';
parameter.history_Z = history_Z(:);
parameter.var_num = 5;              % number of variables

parameter.a_H = 5;                  % max production rate of Hes1 
parameter.a_D = 0.5;                % max production rate of Dll1 by Hes1
parameter.a_J = 1.0;                % max production rate of Jag1 
parameter.a_w = 1.0;                  % max production rate of Dll1 by Ptf1a
parameter.a_N = 0.5;                % max production rate of Notch
parameter.a_P = 0.1;                % max production rate of Ptf1a

parameter.tau_0 = [40,0.1];         % time delay of Hes1 and Dll1 (0.1, no deley)

parameter.tau_h = 20;               % decay time of Hes1
parameter.tau_d = 50;               % decay time of Dll1
parameter.tau_j = 120;              % decay time of Jag1
parameter.tau_n = 50;               % decay time of Notch
parameter.tau_p = 120;              % decay time of Ptf1a
               
% for Dll1
parameter.r11 = 0.25;              % rate parameter for cis
parameter.r21 = 0.1;               % rate parameter for trans              

% for Jag1
parameter.r12 = parameter.r11;      % rate parameter for cis
parameter.r22 = parameter.r21;      % rate parameter for trans              

parameter.K1 =  0.5;                % Hes1 --| Hes1
parameter.K2 =  0.5;               % [NICD] --> Hes1
parameter.K3 =  1.0;                 % Hes1 --| Dll1
parameter.K41 = 10.0;                % Ptf1a -->Dll1
parameter.K42 = 4.0;                % Ptf1a -->Jag1
parameter.K5 =  0.2;                 % Hes1 --| Ptf1a

parameter.Dll1_delay_1 = 10;         % Transcription delay for Dll1 (type2 mutant)
parameter.Dll1_delay_2 = 18;         % Transcription delay for Dll1 making Oscillation recover

% for different cis and trans interaction strength
parameter.big_K2 = 0.1; % 0.9
parameter.small_K2 = 0.01;% 0.15     
parameter.big_r1 = 0.5;%0.4
parameter.small_r1 = 0.05;%0.1

save parameter_for_2 parameter

%% Figure 2c-e, 2g-h: different trans-interaction and cis-interaction
% Plot of Hes1 and Dll1
color1 = [0.9,0.8,0.8];
color2 = [0.8,0.8,0.9];
color20 = [0.7,0.1,0.2];
color10 = [0.1,0.2,0.7];

load('parameter_for_2.mat')
K2_set = [parameter.big_K2, parameter.K2, parameter.small_K2]; % weak trans, wildtype, strong trans
r1_set = [parameter.small_r1, parameter.r11, parameter.big_r1]; % weak trans, wildtype, strong trans
% close all
for caseID = 1:2
    load('parameter_for_2.mat')
    figure('position',[100,800,600,800])
    clear h
    switch caseID
        case 1
            xx_lim = [24,16,4];
            yy_lim = [5,10,18];  
            yw = [0:2:4;0:4:8;0:6:12];
        case 2
            xx_lim = [4,16,24];
            yy_lim = [8,10,12];
            yw = [0:4:8;0:4:8;0:6:12]; 
    end
            
    for i = 1:3
        switch caseID
            case 1
                parameter.K2 = K2_set(i);
            case 2
                parameter.r11 = r1_set(i);
                parameter.r12 = r1_set(i);
        end

        h(2*i-1) = subplot(4,2,2*i-1);
        sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
        i0 = find(sol.x>0,1,'first');
        i1 = find(sol.x>3300,1,'first');

        plot(sol.y(3,i0:end),sol.y(1,i0:end),'-','color',color1,'linewidth',2)
        hold on
        plot(sol.y(4,i0:end),sol.y(2,i0:end),'-','color',color2,'linewidth',2)

        plot(sol.y(3,i1:end),sol.y(1,i1:end),'-','color',color10,'linewidth',2)
        hold on
        plot(sol.y(4,i1:end),sol.y(2,i1:end),'-','color',color20,'linewidth',2)

        scatter(sol.y(3:4,1),sol.y(1:2,1),100,[color10;color20],'v','filled')
        if i == 3
            xlabel('Dll1')
        end
        ylabel('Hes1', 'Units', 'normalized','Position',[-0.2,0.5])
        ylim([-0.1*yy_lim(i),yy_lim(i)])
        yy = ylim;
        xlim([-0.1*xx_lim(i),xx_lim(i)])
        box off
        set(gca,'xtick',0:xx_lim(i)/2:xx_lim(i),'xticklabel',0:xx_lim(i)/2:xx_lim(i))
        set(gca,'ytick',yw(i,:),'yticklabel',yw(i,:))
        set(gca,'fontsize',16,'linewidth',2,'ticklength',[0.03,0.03],'TickDir','out')

        h(2*i) = subplot(4,2,2*i);
        i0 = find(sol.x>0,1,'first');
        box off
        hold on
        clear g
        g(1) = plot(sol.x(1,i0:end),sol.y(1,i0:end),'-','color',color10,'linewidth',2);
        g(2) = plot(sol.x(1,i0:end),sol.y(2,i0:end),'-','color',color20,'linewidth',2);
        xlim([0,2000])
        ylim([-0.1*yy_lim(i),yy_lim(i)])
        set(gca,'ytick',yw(i,:),'yticklabel',yw(i,:))
        if i == 3
            xlabel('Time')
        end
        set(gca,'fontsize',16,'linewidth',2,'ticklength',[0.015,0.015],'TickDir','out')
    end

    for i = 1:2:6
        h(i).Position(3) = h(i).Position(3)-0.12;
        h(i).Position(1) = h(i).Position(1)-0.05;
    end
    for i = 2:2:6
        h(i).Position(1) = h(i).Position(1)-0.2;
        h(i).Position(3) = h(i).Position(3)+0.2;
    end
end
%% SuppFigure 2a-b: different trans-interaction and cis-interaction
% Plot of Jag1, Notch, Ptf1a
color1 = [0.9,0.8,0.8];
color2 = [0.8,0.8,0.9];
color20 = [0.7,0.1,0.2];
color10 = [0.1,0.2,0.7];

load('parameter_for_2.mat')
K2_set = [parameter.big_K2, parameter.K2, parameter.small_K2]; % weak trans, wildtype, strong trans
r1_set = [parameter.small_r1, parameter.r11, parameter.big_r1]; % weak trans, wildtype, strong trans

% close all
linestyles = {'-','-.','--'};
for caseID = 1:2
    load('parameter_for_2.mat')
    figure('position',[100,400,450,300])
    clear h
    switch caseID
        case 1
            xx_lim = [24,16,4];
            yy_lim = [5,10,18];  
            yw = [0:2:4;0:4:8;0:6:12];
        case 2
            xx_lim = [4,16,24];
            yy_lim = [8,10,12];
            yw = [0:4:8;0:4:8;0:6:12]; 
    end
            
    for i = 1:3
        switch caseID
            case 1
                parameter.K2 = K2_set(i);
            case 2
                parameter.r11 = r1_set(i);
                parameter.r12 = r1_set(i);
        end

        sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
        i0 = find(sol.x>0,1,'first');
        i1 = find(sol.x>3300,1,'first');

        % Jag1
        subplot(3,3,1+3*(i-1));
        plot(sol.x(1,i0:end),sol.y(5,i0:end),'-','color',color10,'linewidth',2)
        hold on
        
        plot(sol.x(1,i0:end),sol.y(6,i0:end),'-','color',color20,'linewidth',2)
        
        
        % Ptf1a
        subplot(3,3,2+3*(i-1));
        plot(sol.x(1,i0:end),sol.y(9,i0:end),'-','color',color10,'linewidth',2)
        hold on
        plot(sol.x(1,i0:end),sol.y(10,i0:end),'-','color',color20,'linewidth',2)
        
        
        % Notch
        subplot(3,3,3*i);
        plot(sol.x(1,i0:end),sol.y(7,i0:end),'-','color',color10,'linewidth',2)
        hold on
        plot(sol.x(1,i0:end),sol.y(8,i0:end),'-','color',color20,'linewidth',2)
        
    end
    
    for i = 1:3:9
        subplot(3,3,i)
        xlim([0,2000])
        ylim([-0.1*10,10])
        if i == 7
           xlabel('Time')
        end
        if i == 1
            title('Jag1','FontWeight','normal')
        end
        
        set(gca,'fontsize',16,'linewidth',2,'ticklength',[0.015,0.015],'TickDir','out') 
    end       

    for i = 2:3:9
        subplot(3,3,i)
        xlim([0,2000])
        ylim([-0.1*10,10])
       
%         set(gca,'ytick',yw(i,:),'yticklabel',yw(i,:))
        if i == 8
            xlabel('Time')
        end
        if i == 2
            title('Ptf1a','FontWeight','normal')
        end
        set(gca,'fontsize',16,'linewidth',2,'ticklength',[0.015,0.015],'TickDir','out') 
    end 
   
    for i = 3:3:9
        subplot(3,3,i)
        xlim([0,2000])
        ylim([-0.1*15,15])
%         set(gca,'ytick',yw(i,:),'yticklabel',yw(i,:))
        if i == 9
           xlabel('Time')
        end
        if i == 3
            title('Notch','FontWeight','normal')
        end
        set(gca,'fontsize',16,'linewidth',2,'ticklength',[0.015,0.015],'TickDir','out') 
    end
    
    for i = 1:9
        subplot(3,3,i)
        box off
        if i < 7
        set(gca,'xticklabel','')
        end
    end
    
    for i = 4:6
        h = subplot(3,3,i);
        h.Position(2) = h.Position(2)+0.06;
    end
    
    for i = 7:9
        h = subplot(3,3,i);
        h.Position(2) = h.Position(2)+0.12;
    end
    
    
end

%% SuppFigure 2c–f 3*3 of different trans and cis interaction: 
color20 = [0.7,0.1,0.2];
color10 = [0.1,0.2,0.7];

for caseID = 1:3
    load('parameter_for_2.mat')
    K2_set = [parameter.big_K2, parameter.K2, parameter.small_K2]; % weak trans, wildtype, strong trans
    r1_set = [parameter.small_r1, parameter.r11, parameter.big_r1]; % weak trans, wildtype, strong trans

    figure('position',[100,800,215,200])
    fig_i = 0;
    switch caseID
        case 2
           parameter.a_D = 0;
           parameter.a_w = 0;
        case 3
           parameter.a_J = 0;
    end
    for i = 1:length(K2_set)
        for j = 1:length(r1_set)
            parameter.K2 = K2_set(i);
            parameter.r11 = r1_set(j);
            parameter.r12 = r1_set(j);
            sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
            i0 = find(sol.x>0,1,'first');
            i1 = find(sol.x>3300,1,'first');
            fig_i = fig_i+1;

            h = subplot(length(K2_set),length(r1_set),fig_i);
%             plot(sol.y(3,i1:end),sol.y(1,i1:end),'-','color',color10,'linewidth',2)
%             hold on
%             plot(sol.y(4,i1:end),sol.y(2,i1:end),'-','color',color20,'linewidth',2)

            plot(sol.x(1,i1:end),sol.y(1,i1:end),'-','color',color10,'linewidth',1.5)
            hold on
            plot(sol.x(1,i1:end),sol.y(2,i1:end),'-','color',color20,'linewidth',1.5)
            xlim([3250,3650])
            ylim([-2,22])
            box on
            set(gca,'linewidth',0.5,'Xtick',[],'Ytick',[],'color','none')
            h.Position(3:4) = h.Position(3:4)*1.2;          
        end
    end


end


%% SuppFigure 2g–h: simulate with different Dll1 time delay

clc
% close all
R1_0_Gene_Expression = struct;

for caseID = 1:3
    load('parameter_for_2.mat')
    parameter.a_J = 0;
switch caseID
    case 1
         sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
         sol.Statistic = Estimate_Hes1_AP_Ptf1a_Mean(sol, parameter);
         S = calculate_Notch_signaling(sol,parameter);
         sol.S = S;
        R1_Gene_Expression.Wildtype_no_Jag1 = sol;
    case 2
        parameter.tau_0(2) = 10;
        sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
        sol.Statistic = Estimate_Hes1_AP_Ptf1a_Mean(sol, parameter);
        S = calculate_Notch_signaling(sol,parameter);
        sol.S = S;
        R1_Gene_Expression.Wildtype_no_Jag1_Dll1_delayed = sol;  
    case 3
        parameter.tau_0(2) = 18;
        sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
        sol.Statistic = Estimate_Hes1_AP_Ptf1a_Mean(sol, parameter);
        S = calculate_Notch_signaling(sol,parameter);
        sol.S = S;
        R1_Gene_Expression.Wildtype_no_Jag1_Dll1_delayed_extra = sol; 
    case 4
        parameter.tau_0(2) = 20;
        parameter.a_J = 1;
        sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
        sol.Statistic = Estimate_Hes1_AP_Ptf1a_Mean(sol, parameter);
        S = calculate_Notch_signaling(sol,parameter);
        sol.S = S;
        R1_Gene_Expression.Wildtype_Dll1_delay = sol; 
    case 5
        parameter.tau_0(2) = 0.1;
        parameter.a_J = 1;
        sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
        sol.Statistic = Estimate_Hes1_AP_Ptf1a_Mean(sol, parameter);
        S = calculate_Notch_signaling(sol,parameter);
        sol.S = S;
        R1_Gene_Expression.Wildtype = sol;        
end
end

% Plot
% close all
cell_id = [1,2];
xrange = [0,1000];
lwd = 2;
Hes1_color = [248,186,0]/255;    % Hes1
Delta_color = [255,100,78]/255;  % Delta
Jag1_color = [0,0,1];  % Jag1
Notch_color = [0.1,0.8,0.3];     % Notch 
Ptf1a_color = [0,0,0];          % Ptf1a
NICD_color = [0.6,0.1,0.6];
yy = [0,4.2;0,4.2;0,18;0,18;0,0.12;0,0.12];

figure('position',[10,100,700,700])
for caseID = 1:3
    switch caseID
        case 1
            sol = R1_Gene_Expression.Wildtype_no_Jag1;
        case 2
            sol = R1_Gene_Expression.Wildtype_no_Jag1_Dll1_delayed ;
        case 3
            sol = R1_Gene_Expression.Wildtype_no_Jag1_Dll1_delayed_extra;
    end
    
    subplot(6,3,1+caseID-1)
    plot(sol.x,sol.y(1,:),'-','linewidth',lwd,'color',Hes1_color)
    hold on
    plot(sol.x,sol.y(3,:),'-','linewidth',lwd,'color',Delta_color)
%     plot(sol.x,sol.y(5,:),'-','linewidth',lwd,'color',Jag1_color)

    subplot(6,3,4+caseID-1)
    plot(sol.x,sol.y(2,:),'-','linewidth',lwd,'color',Hes1_color)
    hold on
    plot(sol.x,sol.y(4,:),'-','linewidth',lwd,'color',Delta_color)
%     plot(sol.x,sol.y(6,:),'-','linewidth',lwd,'color',Jag1_color)

    subplot(6,3,7+caseID-1)
    plot(sol.x,sol.y(7,:),'-','linewidth',lwd,'color',Notch_color)
    hold on
    plot(sol.x,sol.y(9,:),'-','linewidth',lwd,'color',Ptf1a_color)

    
    subplot(6,3,10+caseID-1)
    plot(sol.x,sol.y(8,:),'-','linewidth',lwd,'color',Notch_color)
    hold on
    plot(sol.x,sol.y(10,:),'-','linewidth',lwd,'color',Ptf1a_color)

    subplot(6,3,13+caseID-1)
    plot(sol.x,sol.S(1,:),'-','linewidth',lwd,'color', NICD_color)
    hold on
 
    subplot(6,3,16+caseID-1)
    plot(sol.x,sol.S(2,:),'-','linewidth',lwd,'color', NICD_color)
    hold on
        
end

title_str = {'Delay = 0 min','Delay = 10 min','Delay = 18 min'};
for i = 1:18
    subplot(6,3,i)
    xlim(xrange)
    h = gca;
    h.Position(3) = h.Position(3)*1.2;
    h.Position(4) = h.Position(4)*0.8;
    if ismember(i,1:3:18)
       h.Position(1) = h.Position(1)-0.02;
    elseif ismember(i,3:3:18)
       h.Position(1) = h.Position(1)+0.02;  
    end

    ylim(yy(floor((i-0.5)/3)+1,:))
    set(gca,'xtick',0:xrange(2)/2:xrange(2),'xticklabel',0:xrange(2)/2:xrange(2))
    if i < 16
        set(gca,'XTickLabel','')
    end
    
    
    if ismember(i,[1,2,3])
       title(title_str{i},'fontweight','normal','Units', 'normalized', 'Position', [0.5, 1.6, 0]) 
    end
    
    
        xx = 0:4:4;
        if ismember(i,1:6)
           set(gca,'YTick',xx,'YTicklabel','')  
        end
        if i == 1
           set(gca,'YTickLabel',xx) 
           ylabel('Cell 1')
        end
        if i == 4
           set(gca,'YTickLabel',xx) 
           ylabel('Cell 2')
        end
        
        xx = 0:15:15;
        if ismember(i,7:12)
           set(gca,'YTick',xx,'YTicklabel','') 
           
        end
        if i == 7
           set(gca,'YTickLabel',xx) 
           ylabel('Cell 1')
        end
        if i == 10
           set(gca,'YTickLabel',xx) 
           ylabel('Cell 2')
        end
        
        xx = 0:0.1:0.1;
        if ismember(i,13:18)
           set(gca,'YTick',xx,'YTicklabel','') 
           
        end
        if i == 13
           set(gca,'YTickLabel',xx) 
           ylabel('Cell 1')
        end
        if i == 16
           set(gca,'YTickLabel',xx) 
           ylabel('Cell 2')
        end
        
        if ismember(i,[4:6,10:12,16:18])
           h.Position(2) = h.Position(2)+0.02;
        end
        
        if i == 17
            xlabel('Time')
        end
        
        
        
    h.YLabel.Position(1) = -180;
%     h.YLabel.Color = [0.8,0.3,0.3];
    set(gca,'linewidth',1.5,'box','off','fontsize',14,'TickLength',[0.03,0.03],'TickDir','out')
end

% plot in-phase out-phase, phase die out

load('parameter_for_2.mat')
parameter.a_J = 0;
T = 70;
X1 = zeros(2,T);% max min
parameter.tspan = [0,1000];
for i = 1:T
    i
    parameter.tau_0(2) = i;
    sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
    k = find(sol.x>600,1,'first');
    X1(:,i) = [max(sol.y(1,k:end));min(sol.y(1,k:end))];   
end

%
figure('position',[10,100,250,200])
plot(1:T,X1(1,:),'r.-','linewidth',2,'markersize',1)
hold on
plot(1:T,X1(2,:),'b.-','linewidth',2,'markersize',1)
legend('Max','Min')
xlabel('Delay (min)')
ylabel('Hes1 level')
set(gca,'linewidth',1.5,'box','off','fontsize',16,'TickLength',[0.01,0.01],'TickDir','out')






















