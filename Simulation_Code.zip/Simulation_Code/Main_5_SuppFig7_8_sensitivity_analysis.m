
%% SuppFigure 5: Plot phase diagrams for each parameter
color1 = [0.9,0.8,0.8];
color2 = [0.8,0.8,0.9];
color10 = [0.1,0.2,0.7];
color20 = [0.7,0.1,0.2];
load('parameter_for_2.mat')
Para = {'a_H','a_D','a_J','a_w','a_N','a_P',...
    '\tau_0', '\tau_h','\tau_d','\tau_j','\tau_n','\tau_p',...
    '\gamma_1','\gamma_2','K_1','K_2','K_3','K_4_1','K_4_2','K_5'};
p0 = [parameter.a_H,parameter.a_D,parameter.a_J,parameter.a_w,parameter.a_N,parameter.a_P,...
    parameter.tau_0(1),parameter.tau_h,parameter.tau_d,parameter.tau_j,parameter.tau_n,parameter.tau_p,...
    parameter.r11, parameter.r21, parameter.K1, parameter.K2,  parameter.K3, parameter.K41, parameter.K42, parameter.K5];

M = cell(20,2);
s = 0.01:0.01:2;
%%
for caseID = 2:20
    caseID
    load('parameter_for_2.mat')
    tmp1 = zeros(length(s),2);
    tmp = zeros(length(s),4);
    xstr = Para{caseID};  
        switch caseID 
            case 1
               
                for i = 1:length(s)
                    parameter.a_H = s(i)*p0(caseID);
                    SuppFigure7_find_AP;
                end
                
            case 2
                
                for i = 1:length(s)
                    parameter.a_D = s(i)*p0(caseID);
                    SuppFigure7_find_AP;   
                end
            case 3                    

                for i = 1:length(s)
                    parameter.a_J = s(i)*p0(caseID);
                    SuppFigure7_find_AP;
                end
            case 4
              
                for i = 1:length(s)
                    parameter.a_w = s(i)*p0(caseID);
                    SuppFigure7_find_AP;
                end
            case 5

                for i = 1:length(s)
                    parameter.a_N = s(i)*p0(caseID);
                    SuppFigure7_find_AP;
                end 
            case 6
                
                for i = 1:length(s)
                    parameter.a_P = s(i)*p0(caseID);
                    SuppFigure7_find_AP;
                end
            case 7

                for i = 1:length(s)
                    parameter.tau_0(1) = s(i)*p0(caseID);
                    if parameter.tau_0(1) == 0
                        parameter.tau_0(1) = 0.1;
                    end
                    SuppFigure7_find_AP;
                end
            case 8

                for i = 1:length(s)
                    parameter.tau_h = s(i)*p0(caseID);
                    SuppFigure7_find_AP;
                end
                
             case 9
                for i = 1:length(s)
                    parameter.tau_d = s(i)*p0(caseID);
                    SuppFigure7_find_AP;
                end
                
            case 10
                for i = 1:length(s)
                    parameter.tau_j = s(i)*p0(caseID);
                    SuppFigure7_find_AP;
                end
             case 11
                for i = 1:length(s)
                    parameter.tau_n = s(i)*p0(caseID);
                    SuppFigure7_find_AP;
                end
                
            case 12
            for i = 1:length(s)
                parameter.tau_p = s(i)*p0(caseID);
                SuppFigure7_find_AP;
            end
            
            case 13
            for i = 1:length(s)
                parameter.r11 = s(i)*p0(caseID);
                parameter.r12 = s(i)*p0(caseID);
                SuppFigure7_find_AP;
            end
            
            case 14
            for i = 1:length(s)
                parameter.r21 = s(i)*p0(caseID);
                parameter.r22 = s(i)*p0(caseID);
                SuppFigure7_find_AP;
            end
            
            case 15
            for i = 1:length(s)
                parameter.K1 = s(i)*p0(caseID);      
                SuppFigure7_find_AP;
            end
            
            case 16
            for i = 1:length(s)
                parameter.K2 = s(i)*p0(caseID);
                SuppFigure7_find_AP;
            end
            
            case 17
            for i = 1:length(s)
                parameter.K3 = s(i)*p0(caseID);               
                SuppFigure7_find_AP;
            end
            
            case 18
            for i = 1:length(s)
                parameter.K41 = s(i)*p0(caseID);
                SuppFigure7_find_AP;
            end
            
            case 19
            for i = 1:length(s)
                parameter.K42 = s(i)*p0(caseID);               
                SuppFigure7_find_AP;
            end
    
            case 20
            for i = 1:length(s)
                parameter.K5 = s(i)*p0(caseID);                
                SuppFigure7_find_AP;
            end
        end
    
    M{caseID,1} = tmp1; 
    M{caseID,2} = tmp;  
end

save M_para_A_P_sensitivity_2_model M
%% for plot
Para = {'a_H','a_D','a_J','a_w','a_N','a_P',...
    '\tau_0', '\tau_h','\tau_d','\tau_j','\tau_n','\tau_p',...
    '\gamma_1','\gamma_2','K_1','K_2','K_3','K_6','K_4','K_5'};
p0 = [parameter.a_H,parameter.a_D,parameter.a_J,parameter.a_w,parameter.a_N,parameter.a_P,...
    parameter.tau_0(1),parameter.tau_h,parameter.tau_d,parameter.tau_j,parameter.tau_n,parameter.tau_p,...
    parameter.r11, parameter.r21, parameter.K1, parameter.K2,  parameter.K3, parameter.K41, parameter.K42, parameter.K5];
load('M_para_A_P_sensitivity_2_model.mat')
s = 0.01:0.01:2;
%% Ptf1a
for caseID = 1:20
    xstr = Para{caseID};
    ystr = 'Ptf1a';
    figure('Position',[100,800,200,160])
    plot(p0(caseID)*s,M{caseID,1}(:,1),'.','markersize',5,'color',color20,'linewidth',1.5)
    hold on
    plot(p0(caseID)*s,M{caseID,1}(:,2),'.','markersize',5,'color',color20,'linewidth',1.5)
    y0 = [0,14];
    plot([p0(caseID),p0(caseID)],[0,10],'k--','linewidth',1.5)
    ylim(y0)
    set(gca,'box','off','YDir','normal','linewidth',1.5,'fontsize',14,'TickLength',[0.02,0.02],'TickDir','out')
    set(gca,'xtick',0:p0(caseID):2*p0(caseID),'ytick',0:5:20)
    xlabel(xstr)
    ylabel(ystr)
end
%% Amplitude of Hes1
for caseID = 1:20
    xstr = Para{caseID};
    ystr = 'Amplitude';
    figure('Position',[100,800,200,160])
    plot(p0(caseID)*s,M{caseID,2}(:,1),'.','markersize',5,'color',color20,'linewidth',1.5)
    hold on
    plot(p0(caseID)*s,M{caseID,2}(:,3),'.','markersize',5,'color',color20,'linewidth',1.5)
    y0 = [0,14];
    plot([p0(caseID),p0(caseID)],[0,10],'k--','linewidth',1.5)
    ylim(y0)
    set(gca,'box','off','YDir','normal','linewidth',1.5,'fontsize',14,'TickLength',[0.02,0.02],'TickDir','out')
    set(gca,'xtick',0:p0(caseID):2*p0(caseID),'ytick',0:5:20)
    xlabel(xstr)
    ylabel(ystr)
end

%% period of Hes1
for caseID = 1:20
    xstr = Para{caseID};
    ystr = 'Period';
    figure('Position',[100,800,200,160])
    plot(p0(caseID)*s,M{caseID,2}(:,2),'.','markersize',5,'color',color20,'linewidth',1.5)
    hold on
    plot(p0(caseID)*s,M{caseID,2}(:,4),'.','markersize',5,'color',color20,'linewidth',1.5)
    %y0 = [0,130];
    plot([p0(caseID),p0(caseID)],[0,130],'k--','linewidth',1.5)
    xlim([0,p0(caseID)*2])
    
    set(gca,'box','off','YDir','normal','linewidth',1.5,'fontsize',14,'TickLength',[0.02,0.02],'TickDir','out')
    set(gca,'xtick',0:p0(caseID):2*p0(caseID),'ytick',0:40:160)
    xlabel(xstr)
    ylabel(ystr)
end

     