function Plot_Gene_Dynamic(sol, parameter, cell_id, range, title_or_not)
% Plot gene expression dynamics of example cells within time interval,
% range
% figure size optimazed for 3 examples

cells = cell_id;
y_top = 0;
legend_str = {'Hes1','Dll','Jag1','Notch','Ptf1a'};
title_str = {'BP','MPC','PAC'};
Hes1_color = [248,186,0]/255;    % Hes1
Delta_color = [255,100,78]/255;  % Delta
Jag1_color = [0,0,1];  % Jag1
Ptf1a_color = [0,0,0];          % Ptf1a
Notch_color = [0.1,0.8,0.3];     % Notch          
colors = [Hes1_color;Delta_color;Jag1_color;Notch_color;Ptf1a_color];
figure('position',[10,800,320,350])
for ii = 1:length(cells)
    i = cells(ii);
    subplot(length(cells),1,ii)
    for j = 1:3
        plot(sol.x,sol.y(parameter.N*(j-1)+i,:),'color',colors(j,:),'linewidth',2)
        hold on
    end
    xlim(range)
    if title_or_not == 1
    title(['Cell ',num2str(i),': ',title_str{sol.Statistic(i,4)}])
    end
    set(gca,'linewidth',1.5,'fontsize',14,'TickLength',[0.02,0.02],'TickDir','out')
    if y_top>0
        ylim([0,y_top])
    end
    box off
    if ii == 1
       x_tick = get(gca,'Xtick');
    else 
        set(gca,'Xtick',x_tick)
    end
    if ii == length(cells)
       xlabel('Time')
    else
       set(gca,'XtickLabel','')
    end
    if ii == 2
        ylabel('Expression')
    end
end

figure('position',[330,800,320,350])
for ii = 1:length(cells)
    i = cells(ii);
    subplot(length(cells),1,ii)
    for j = 4:5%parameter.var_num
        plot(sol.x,sol.y(parameter.N*(j-1)+i,:),'color',colors(j,:),'linewidth',2)
        hold on
    end
    if ii == 2
        ylabel('Expression')
    end
    
    yyaxis right
    NICD_color = [0.6,0.1,0.6];
    plot(sol.x,sol.S(i,:),'-','linewidth',2,'color', NICD_color)
    xlim(range)
    if title_or_not == 1
    title(['Cell ',num2str(i),': ',title_str{sol.Statistic(i,4)}])
    end
    set(gca,'linewidth',1.5,'fontsize',14,'TickLength',[0.02,0.02],'TickDir','out')
    if y_top>0
        ylim([0,y_top])
    end
    box off
    
    if ii == 1
       x_tick = get(gca,'Xtick');
    else 
        set(gca,'Xtick',x_tick)
    end
    if ii == length(cells)
       xlabel('Time')
    else
       set(gca,'XtickLabel','')
    end
    if ii == 2
        ylabel('{\itTrans}-activation of Hes1')
    end
    
    ax = gca;
    ax.YAxis(2).Color = NICD_color;
end

end

