%% SuppFigure 6: slow and fast Ptf1a
clc
close all
load('R1_Parameter_mDelay.mat')
r = [0.5,2,50];
title_str = {'Slow Ptf1a','Fast Ptf1a','superFast Ptf1a'};
for i = 1:1
    load([title_str{i},'.mat'])
    Estimate_Hes1_AP_Ptf1a_Mean(sol, parameter,0);
    Scatter3DPlot(sol, parameter, []);

    F1 = get(gcf,'CurrentAxes');
    axChildren = get(F1,'Children');

    CellFateDistribute(sol, parameter);
    subplot(1,2,2)
    copyobj(axChildren,gca)
    zlim([-3,3])
    xlabel('Dim1','Rotation',0)
    ylabel('Dim2','Rotation',90)
    title('Dim3 \in [-3, 3]','fontweight','normal')
    view(180,90)
    box off
    set(gca,'linewidth',1.5,'fontsize',14,'TickLength',[0.03,0.03],'TickDir','out')

    cell_id = [115,109,95];
    Plot_Gene_Dynamic(sol, parameter, cell_id, [0,3200],0)  
end

%%
title_str = {'Fast Ptf1a','Wildtype','Slow Ptf1a'};
figure('Position',[10,800,380,230])
colors = [0,0,1;0,0,0;0.8,0.3,0.3;];
for i = 1:3
    load([title_str{i},'.mat'])
    plot(sol.x,sol.y(parameter.N*4+109,:),'-','linewidth',1.5,'color',colors(i,:))
    hold on
end
set(gca,'box','off','linewidth',1.5,'fontsize',14,'TickLength',[0.03,0.03],'TickDir','out')
xlim([0,3600])
ylim([0,9])
xlabel('Time')
ylabel('Ptf1a')
h = legend('Fast (\delta = 2)','Wild-type (\delta = 1)','Slow (\delta = 0.5)','location','southeast','Orientation','horizontal');
h.Position = [0.1, 0.9, 0.5, 0.0760];