function CellFateDistribute(sol, parameter)
%Plot cell fate distribution along R
R = sqrt(parameter.cell_center(:,1).^2 + parameter.cell_center(:,2).^2 + parameter.cell_center(:,3).^2 );
binwidth = 0.5;
e = 0:binwidth:max(R);
e(1) = -0.1;
e = [e,max(R)+binwidth];
I = discretize(R,e);
CLabel = {'BP','MPC','PAC','Total'};
figure('position',[100,800,500,220])

subplot(1,2,1)
T = zeros(max(I),1);
for i = 1:max(I)
    T(i) = sum(I==i);
end
a = [0.1,0.1,0.8];
for i = 1:3
    histogram(R(sol.Statistic(:,4)==i),e,'EdgeColor',parameter.fate_colors(i,:),...
        'facecolor',parameter.fate_colors(i,:),'FaceAlpha',a(i),'linewidth',1.5);
    hold on
end
plot(e(1:end-1)+binwidth/2,T,'.-','color',[0.3,0.3,0.3],'linewidth',1.5,'markersize',10)
Lh = legend(CLabel,'Location','northwest');
Lh.Position = [0.14,0.6,0.14,0.3];
xlabel('Distance to center')
ylabel('Cell number')
box off
legend('box','off')
set(gca,'linewidth',1.5,'fontsize',14,'TickLength',[0.03,0.03],'TickDir','out')

%Scatter3DPlot(sol, parameter, [])


end

