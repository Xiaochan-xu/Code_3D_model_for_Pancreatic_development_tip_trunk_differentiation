%% Example for how to simulate the early pancreatic development with Wildtype
load('R1_Parameter.mat')
title_str = 'Wildtype';
Plot_N = 1; 
sol = dde23(@(t,y,Z) Notch_Delta_Hes1_GRN_Hes1_Delta_Jag1_Notch(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);

% Plot amplitude/period of Hes1, level of Ptf1a, cell proportions
sol.Statistic = Estimate_Hes1_AP_Ptf1a_Mean(sol, parameter,Plot_N);
S = calculate_Notch_signaling(sol,parameter);
sol.S = S;

% Plot dynamics of gene expression in showing cells during a given time
% interval
cell_id = [115,109,95];
Plot_Gene_Dynamic(sol, parameter, cell_id, [2500,3000],0)
Plot_Gene_Dynamic(sol, parameter, cell_id, [0,2000],0)

% Plot final fates of cells on the 3D structure, statistics of locations of
% different fates, and cross-section of the 3D structure
Scatter3DPlot(sol, parameter, []);
set(gcf,'Position',[10,800,360,340])
F1 = get(gcf,'CurrentAxes');
axChildren = get(F1,'Children');

CellFateDistribute(sol, parameter);
subplot(1,2,2)
copyobj(axChildren,gca)
zlim([-3,3])
xlabel('Dim1','Rotation',0)
ylabel('Dim2','Rotation',90)
axis equal
xlim([-6,7])
ylim([-6,7])
title('Dim3 \in [-3, 3]','fontweight','normal')
view(180,90)
box off
set(gca,'xtick',-5:5:5,'ytick',-5:5:5,'linewidth',1.5,'fontsize',14,'TickLength',[0.03,0.03],'TickDir','out')
set(gcf,'Position',[10,800,700,300])
