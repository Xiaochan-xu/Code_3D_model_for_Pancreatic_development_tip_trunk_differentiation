
%% SuppFigure 5: Plot phase diagrams for each parameter
color1 = [0.9,0.8,0.8];
color2 = [0.8,0.8,0.9];
color10 = [0.1,0.2,0.7];
color20 = [0.7,0.1,0.2];
load('parameter_for_2.mat')
Para = {'a_H','a_D','a_J','a_w','a_N','a_P',...
    '\tau_0', '\tau_h','\tau_d','\tau_j','\tau_n','\tau_p',...
    '\gamma_1','\gamma_2','K_1','K_2','K_3','K_4_1','K_4_2','K_5'};
p0 = [parameter.a_H,parameter.a_D,parameter.a_J,parameter.a_w,parameter.a_N,parameter.a_P,...
    parameter.tau_0(1),parameter.tau_h,parameter.tau_d,parameter.tau_j,parameter.tau_n,parameter.tau_p,...
    parameter.r11,parameter.r21, parameter.K1, parameter.K2,  parameter.K3, parameter.K41, parameter.K42, parameter.K5];

M = cell(20,1);
s = 0.01:0.01:2;
%%
for caseID = 14:14
    caseID
    load('parameter_for_2.mat')
    tmp = zeros(length(s),2);
    xstr = Para{caseID};  
        switch caseID 
            case 1
               
                for i = 1:length(s)
                    parameter.a_H = s(i)*p0(caseID);
                    sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
                    tmp(i,1) = mean(sol.y(5,sol.x>3300));
                    tmp(i,2) = mean(sol.y(6,sol.x>3300));
                end
                
            case 2
                
                for i = 1:length(s)
                    parameter.a_D = s(i)*p0(caseID);
                    sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
                    tmp(i,1) = mean(sol.y(9,sol.x>3300));
                    tmp(i,2) = mean(sol.y(10,sol.x>3300));
                    
                end
            case 3                    

                for i = 1:length(s)
                    parameter.a_J = s(i)*p0(caseID);
                    sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
                    tmp(i,1) = mean(sol.y(9,sol.x>3300));
                    tmp(i,2) = mean(sol.y(10,sol.x>3300));
                end
            case 4
              
                for i = 1:length(s)
                    parameter.a_w = s(i)*p0(caseID);
                    sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
                    tmp(i,1) = mean(sol.y(9,sol.x>3300));
                    tmp(i,2) = mean(sol.y(10,sol.x>3300));
                end
            case 5

                for i = 1:length(s)
                    parameter.a_N = s(i)*p0(caseID);
                    sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
                    tmp(i,1) = mean(sol.y(9,sol.x>3300));
                    tmp(i,2) = mean(sol.y(10,sol.x>3300));
                end 
            case 6
                
                for i = 1:length(s)
                    parameter.a_P = s(i)*p0(caseID);
                    sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
                    tmp(i,1) = mean(sol.y(9,sol.x>3300));
                    tmp(i,2) = mean(sol.y(10,sol.x>3300));
                end
            case 7

                for i = 1:length(s)
                    parameter.tau_0(1) = s(i)*p0(caseID);
                    if parameter.tau_0(1) == 0
                        parameter.tau_0(1) = 0.1;
                    end
                    sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
                    tmp(i,1) = mean(sol.y(9,sol.x>3300));
                    tmp(i,2) = mean(sol.y(10,sol.x>3300));
                end
            case 8

                for i = 1:length(s)
                    parameter.tau_h = s(i)*p0(caseID);
                    sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
                    tmp(i,1) = mean(sol.y(9,sol.x>3300));
                    tmp(i,2) = mean(sol.y(10,sol.x>3300));
                end
                
             case 9
                for i = 1:length(s)
                    parameter.tau_d = s(i)*p0(caseID);
                    sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
                    tmp(i,1) = mean(sol.y(9,sol.x>3300));
                    tmp(i,2) = mean(sol.y(10,sol.x>3300));
                end
                
            case 10
                for i = 1:length(s)
                    parameter.tau_j = s(i)*p0(caseID);
                    sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
                    tmp(i,1) = mean(sol.y(9,sol.x>3300));
                    tmp(i,2) = mean(sol.y(10,sol.x>3300));
                end
             case 11
                for i = 1:length(s)
                    parameter.tau_n = s(i)*p0(caseID);
                    sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
                    tmp(i,1) = mean(sol.y(9,sol.x>3300));
                    tmp(i,2) = mean(sol.y(10,sol.x>3300));
                end
                
            case 12
            for i = 1:length(s)
                parameter.tau_p = s(i)*p0(caseID);
                sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
                tmp(i,1) = mean(sol.y(9,sol.x>3300));
                tmp(i,2) = mean(sol.y(10,sol.x>3300));
            end
            
            case 13
            for i = 1:length(s)
                parameter.r11 = s(i)*p0(caseID);
                parameter.r12 = s(i)*p0(caseID);
                sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
                tmp(i,1) = mean(sol.y(9,sol.x>3300));
                tmp(i,2) = mean(sol.y(10,sol.x>3300));
            end
            
            case 14
            for i = 1:length(s)
                parameter.r21 = s(i)*p0(caseID);
                parameter.r22 = s(i)*p0(caseID);
                
                sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
                tmp(i,1) = mean(sol.y(9,sol.x>3300));
                tmp(i,2) = mean(sol.y(10,sol.x>3300));
            end
            
            case 15
            for i = 1:length(s)
                parameter.K1 = s(i)*p0(caseID);      
                sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
                tmp(i,1) = mean(sol.y(9,sol.x>3300));
                tmp(i,2) = mean(sol.y(10,sol.x>3300));
            end
            
            case 16
            for i = 2:length(s)
                parameter.K2 = s(i)*p0(caseID);
                sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
                tmp(i,1) = mean(sol.y(9,sol.x>3300));
                tmp(i,2) = mean(sol.y(10,sol.x>3300));
            end
            
            case 17
            for i = 1:length(s)
                parameter.K3 = s(i)*p0(caseID);               
                sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
                tmp(i,1) = mean(sol.y(9,sol.x>3300));
                tmp(i,2) = mean(sol.y(10,sol.x>3300));
            end
            
            case 18
            for i = 1:length(s)
                parameter.K41 = s(i)*p0(caseID);
                sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
                tmp(i,1) = mean(sol.y(9,sol.x>3300));
                tmp(i,2) = mean(sol.y(10,sol.x>3300));
            end
            
            case 19
            for i = 2:length(s)
                parameter.K42 = s(i)*p0(caseID);               
                sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
                tmp(i,1) = mean(sol.y(9,sol.x>3300));
                tmp(i,2) = mean(sol.y(10,sol.x>3300));
            end
    
            case 20
            for i = 2:length(s)
                parameter.K5 = s(i)*p0(caseID);                
                sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
                tmp(i,1) = mean(sol.y(9,sol.x>3300));
                tmp(i,2) = mean(sol.y(10,sol.x>3300));
            end
        end
    
    M{caseID,1} = tmp;   
end

%save M_para_sensitivity_2_model_10_20 M
%%
for caseID = 14:14
    xstr = Para{caseID};
    ystr = 'Ptf1a';
    figure('Position',[100,800,200,160])
    plot(p0(caseID)*s,M{caseID,1},'.','markersize',5,'color',color20,'linewidth',1.5)
    hold on
    plot(p0(caseID)*s,M{caseID,1},'.','markersize',5,'color',color20,'linewidth',1.5)
    y0 = [0,14];
    plot([p0(caseID),p0(caseID)],[0,10],'k--','linewidth',1.5)
    ylim(y0)
    set(gca,'box','off','YDir','normal','linewidth',1.5,'fontsize',14,'TickLength',[0.02,0.02],'TickDir','out')
    set(gca,'xtick',0:p0(caseID):2*p0(caseID),'ytick',0:5:20)
    xlabel(xstr)
    ylabel(ystr)
end
%%
figure('Position',[100,800,400,160])
s = 0.01:0.01:2;
caseID = 1;
for i = 10:length(s)
    parameter.a_H = s(i)*p0(caseID);
    sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
    
    L = sum(sol.x>3300);
    subplot(2,1,1)
    plot(s(i)*ones(L,1),sol.y(9,sol.x>3300),'k-','linewidth',1.5)
    hold on
    plot(s(i)*ones(L,1),sol.y(1,sol.x>3300),'-','color',color10,'linewidth',1.5)
    
    
    subplot(2,1,2)
    plot(s(i)*ones(L,1),sol.y(10,sol.x>3300),'k-','linewidth',1.5)
    hold on
    plot(s(i)*ones(L,1),sol.y(2,sol.x>3300),'-','color',color20,'linewidth',1.5)
    
    
end
                