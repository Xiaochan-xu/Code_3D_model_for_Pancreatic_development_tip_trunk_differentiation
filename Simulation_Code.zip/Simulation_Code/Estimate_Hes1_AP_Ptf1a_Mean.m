function R = Estimate_Hes1_AP_Ptf1a_Mean(sol,parameter, Plot_N)
% Estimated amplitute of Hes1, period of Hes1, mean level of Ptfa1, and
% cell fates
% Cell fates for each cell are roughly estimated first and manually corrected.  

R = zeros(parameter.N,5);
xx_range = [3200,3600]; % Time interval used to estimate
k1 = find(sol.x>xx_range(1),1,'first');
k2 = find(sol.x<xx_range(2),1,'last');

T = sol.x(k1:k2);
% mean Ptf1a
R(:,3) = mean(sol.y(parameter.N*4+[1:parameter.N],k1:k2),2);
R(:,5) = mean(sol.y(parameter.N*3+[1:parameter.N],k1:k2),2);
Rp = R;
Rp(:,4) = mean(sol.y(parameter.N*2+[1:parameter.N],k1:k2),2);%Jag1
Rp(:,5) = mean(sol.y(parameter.N*1+[1:parameter.N],k1:k2),2);%Dll1
%Rp(R(:,3)>2,3) = 2;
%Rp(R(:,1)>6,1) = 6;
% Amplitute and period of Hes1
for i = 1:parameter.N
    [high_P,loc1] = findpeaks(sol.y(i,k1:k2));%,'MinPeakProminence',4
    [low_P,loc2] = findpeaks(-sol.y(i,k1:k2));%,'MinPeakProminence',4
    low_P = -low_P;
    if ~isempty(high_P)
        R(i,1) = mean(high_P)-mean(low_P);
        R(i,2) = mean(abs(diff(T(loc1))));
    end
end
if parameter.N > 2
    
% estimate cell fate with kmeans
R(:,4) = 2;
CLabel = {'BP','MPC','PAC'};
R(R(:,3)>2,4) = 3; % PAC, Ptf1a >2
R(R(:,1)>3,4) = 1; % BP, Amp. of hes1 > 3
ww = find(R(:,3)<2);
Rp = Rp(ww,:);
[c1,c2] = kmeans(Rp(:,[1,3]),2, 'Replicates',5);
if c2(1,2) < c2(2,2)
   R(ww(c1==1),4) = 1; % BP
else
   R(ww(c1==2),4) = 1; % BP    
end

R(R(:,4) == 3,2) = 0;

k0 = find(R(:,4)==2);
R(k0(R(k0,1)>3),4) = 1; % BP, Amp. of hes1 > 3
%% scatter plot mean of Ptf1a on x, Amplitute of Hes1 on y
figure('position',[100,500,220,220])
for i = 1:3
    plot(R(R(:,4)==i,3),R(R(:,4)==i,1),'o','markersize',8,'color',parameter.fate_colors(i,:),'linewidth',1.5)
    hold on   
end
dxy = [0.5,0;0.5,0.5;-1.5,0.5];
for i = 1:3
    if any(R(:,4)==i)
        center_text = mean(R(R(:,4)==i,[1,3]),1);
        text(center_text(2)+dxy(i,1), center_text(1)+dxy(i,2), [CLabel{i}, ' (', num2str(round(100*sum(R(:,4)==i)/parameter.N)),'%)'], 'fontsize', 14)
    end
end
set(gca,'linewidth',1.5,'fontsize',14,'TickLength',[0.03,0.03],'TickDir','out')
xlabel('Ptf1a')
ylabel('Amplitute of Hes1')
box off
set(gca,'Xtick',0:5:40,'ytick',0:3:30)

if Plot_N > 0
%% mean of Ptf1a on x, Amplitute of Hes1, period of Hes1
figure('position',[100,500,180,400])
fate_plot = [3,2,1];
S_marker = 30;     % markersize

order = [3,1,2];
for j = 1:3
    ht = subplot(3,1,j);
    for ii = 1:length(fate_plot)
        fate_i = fate_plot(ii);
        k_P = find(R(:,4) == fate_i);
        ww = 1/(length(k_P)-1);
        rr_ww = -0.5:ww:0.5;        
        dot_color = parameter.fate_colors(fate_i,:);    
        scatter(ii+0.6*rr_ww,R(k_P,order(j)),S_marker,dot_color,'o','filled')
        hold on
        alpha(0.5) 
        scatter(ii+0.6*rr_ww,R(k_P,order(j)),S_marker,dot_color,'o')
        MM_SD = [mean(R(k_P,order(j))), std(R(k_P,order(j)))];
        plot([ii-0.4,ii+0.4],[MM_SD(1),MM_SD(1)],'linewidth',1.5,'color','k')
        errorbar(ii,MM_SD(1),MM_SD(2),'linewidth',1.5,'color','k','CapSize',10)
    end
    ht.Position(1) = 0.3;
     ht.Position(4) = ht.Position(4)*0.7;
    ht.Position(3) = ht.Position(3)*0.8;
    if j == 1
        ylabel('Ptf1a')
        yy = ylim;
        
        ylim([-0.2,yy(2)])
        set(gca,'ytick',0:floor(yy(2)/2):yy(2),'yticklabel',0:floor(yy(2)/2):yy(2))
    end
    if j == 2
        ylabel('Amplitude')
        yy = ylim;
        ylim([-0.2,yy(2)])
        set(gca,'ytick',0:floor(yy(2)/2):yy(2),'yticklabel',0:floor(yy(2)/2):yy(2))
    end
    if j == 3
        ylabel('Period (min)')
        yy = ylim;
        yy(2) = max(120,yy(2));
        ylim([-5,yy(2)])
        set(gca,'ytick',0:60:yy(2),'yticklabel',0:60:yy(2))
    end
    set(gca,'xtick',1:length(fate_plot),'xticklabel','')
   if j == 3
       set(gca,'xtick',1:length(fate_plot),'xticklabel',{'PAC','MPC','BP'})   
    end
    set(gca,'linewidth',1.5,'fontsize',14,'TickLength',[0.03,0.03],'TickDir','out')
    xlim([0.25,length(fate_plot)+0.75])
    h = gca;
    h.Position(4) = 1.4*h.Position(4);
    box off   
end
end
else
    R(:,4) = 2;
end
end

