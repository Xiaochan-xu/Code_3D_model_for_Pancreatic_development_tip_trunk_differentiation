%% Make movie for supplementary
% Input of dynmamic data
clear
Data = cell(5,2);
load('R1_Parameter_mDelay.mat')
for caseID = 1:5
    % 1: Wild type
    % 2: Dll1 deficient
    % 3: Jag1 deficient
    % 4: DAPT
    % 5: MLN4924
    close all
    tspan = [0,3600];    
    switch caseID
        case 1
            TitleStr = {'Wild type'};
            load('Wildtype.mat');
        case 2
            TitleStr = {'\itDll1 deficient'};
            load('Dll1 deficient.mat');
        case 3
            TitleStr = {'\itJag1 deficient'};
            load('Jag1 deficient.mat');
        case 4
            TitleStr = {'DAPT'};
            load('DAPT.mat');
        case 5
            TitleStr = {'MLN4924'};
            load('MLN4924.mat');        
    end
    Data{caseID,1} = TitleStr;
    Data{caseID,2} = sol;
end
%%
Fs = {'Wildtype','Dll1_deficient','Jag1_deficient','DAPT','MLN4924'};
for caseID = 5:5
    TitleStr = Data{caseID,1};
    filename = [Fs{caseID},'.mp4'];
    sol = Data{caseID,2};
    start_point = 1;
    Hes1_range = [0,3];
    Ptf1a_range = [0,5];
    b_size = 500;
     
    H = figure('position',[100,800,600,300]);
    axis tight manual % this ensures that getframe() returns a consistent size
    h(1) = subplot(2,2,1);
    
   % plot Hes1 and Dll1

    [p1,p2] = find(parameter.interaction_M > 0);
    Ax = parameter.cell_center(p1,1)';
    Ay = parameter.cell_center(p1,2)';
    Az = parameter.cell_center(p1,3)';

    Bx = parameter.cell_center(p2,1)';
    By = parameter.cell_center(p2,2)';
    Bz = parameter.cell_center(p2,3)';

  %  figure('position',[100,800,320,300])
    line([Ax;Bx],[Ay;By],[Az;Bz],'color','k','linewidth',0.5)
    hold on
    
    %cellColors = zeros(parameter.N,3);
    idx = zeros(parameter.N,2);
    idx(:,1) = (sol.y(4*parameter.N+1:5*parameter.N,start_point)-Ptf1a_range(1))/(Ptf1a_range(2)-Ptf1a_range(1));% Ptf1a
    idx(:,2) = (sol.y(1:parameter.N,start_point)-Hes1_range(1))/(Hes1_range(2)-Hes1_range(1));% Hes1
    idx(idx<0) = 0;
    idx(idx>1) = 1;
    %cellColors = [1-idx(:,2),1-idx(:,1)];
    cellColors = [idx(:,1),idx(:,2)];
    cellColors(:,3) = 0;
    
    g(1) = scatter3(parameter.cell_center(:,1),parameter.cell_center(:,2),parameter.cell_center(:,3),b_size,cellColors,'o','filled');

    view([-50,18])
    grid on
    axis equal

    set(gca,'linewidth',1.5,'fontsize',14)
    set(gca,'xtick',-2:2:2,'xticklabel',-2:2:2,'ytick',-2:2:2,'yticklabel',-2:2:2,'ztick',-2:2:2,'zticklabel',-2:2:2)
    xlabel('Dim 1')
    ylabel('Dim 2')
    zlabel('Dim 3')
    
    % plot progress bar
    h(2) = subplot(2,2,2);
    timeP = sol.x(start_point)/tspan(2);
    plot([0,1,1,0,0],[0,0,1,1,0],'k')
    hold on
    TT = fill([0,timeP,timeP,0,0],[0,0,1,1,0],'k');
    set(gca,'fontsize',14,'linewidth',1.5)
    ylabel('Time','rotation',0)
    
    % plot Hes1 and Dll1
    h(3) = subplot(2,2,3);
    lineColors = lines(parameter.N);
    g(2:parameter.N+1) = plot(sol.x(1:start_point),sol.y(parameter.N+1:2*parameter.N,1:start_point),'-');
    for ss = 2:parameter.N+1
        g(ss).Color = lineColors(ss-1,:);
    end
    hold on
    g(parameter.N+2) = scatter(repmat(sol.x(start_point),1,parameter.N),sol.y(parameter.N+1:2*parameter.N,start_point),30,lineColors,'o','filled');
    %xlabel('Time')
    ylabel('Dll1')
    box off
    xlim([0,tspan(2)])
    ylim([0,max(max(max(sol.y(parameter.N+1:2*parameter.N,:),[],2),[],1),5)]);
    set(gca,'fontsize',14,'linewidth',1.5)
    
    % plot Hes1 and Jag1
    h(4) = subplot(2,2,4);
    g(2*parameter.N+3:3*parameter.N+2) = plot(sol.x(1:start_point),sol.y(2*parameter.N+1:3*parameter.N,1:start_point),'-');
    for ss = 2*parameter.N+3:3*parameter.N+2
        g(ss).Color = lineColors(ss-(2*parameter.N+2),:);
    end
    hold on
    g(3*parameter.N+3) = scatter(repmat(sol.x(start_point),1,parameter.N),sol.y(2*parameter.N+1:3*parameter.N,start_point),30,lineColors,'o','filled');
    xlabel('Time')
    ylabel('Jag1')
    xlim([0,tspan(2)])
    ylim([0,max(max(max(sol.y(2*parameter.N+1:3*parameter.N,:),[],2),[],1),5)])
    box off
    set(gca,'fontsize',14,'linewidth',1.5)
    
    h(1).Position = [-0.11,0.12,0.8,0.8];
    h(1).Visible = 'off';
    
    h(2).Position = [0.15,0.1,0.15,0.03];
    h(2).YTick = '';
    h(2).XTick = '';
    h(2).YLabel.Position(1:2) = [-0.23,-0.5];
%     h(2).XTick = [0:1000:3000]/parameter.fake_start;
%     h(2).XTickLabel = parameter.fake_start*h(2).XTick;
    h(3).Position = [0.6,0.55,0.3,0.3];
    h(4).Position = [0.6,0.15,0.3,0.3];
    
    annotation('textbox',[0.4,0.75,0.5,0.2],'String',TitleStr,'color',[0,0,0],'FontSize',16,'EdgeColor','none')
    annotation('textbox',[0.33,0.05,0.5,0.1],'String','Hes1','color',[0.2,0.9,0.2],'FontSize',14,'EdgeColor','none')
    annotation('textbox',[0.40,0.05,0.5,0.1],'String','Ptf1a','color',[0.9,0.2,0.2],'FontSize',14,'EdgeColor','none')
    %annotation('textbox',[0.35,0.1,0.17,0.07],'EdgeColor',[0.1,0.1,0.1],'LineWidth',1)
    
    v = VideoWriter(filename,'MPEG-4');
    v.FrameRate = 10;
    open(v);
    frame = getframe(gcf);
    writeVideo(v,frame);

%        frame = getframe(H); 
%       im = frame2im(frame); 
%       [imind,cm] = rgb2ind(im,256); 
%       % Write to the GIF File 
%       imwrite(imind,cm,filename,'gif', 'Loopcount',inf); 
   
    for j = start_point+1:2:length(sol.x)
            %cellColors = zeros(parameter.N,3);
        idx = zeros(parameter.N,2);
        idx(:,1) = (sol.y(4*parameter.N+1:5*parameter.N,j)-Ptf1a_range(1))/(Ptf1a_range(2)-Ptf1a_range(1));% Ptf1a
        idx(:,2) = (sol.y(1:parameter.N,j)-Hes1_range(1))/(Hes1_range(2)-Hes1_range(1));% Hes1
        idx(idx<0) = 0;
        idx(idx>1) = 1;
        %cellColors = [1-idx(:,2),1-idx(:,1)];
        cellColors = [idx(:,1),idx(:,2)];
        cellColors(:,3) = 0;
    
        g(1).CData = cellColors;
        for s = 1:parameter.N
            g(s+1).XData = sol.x(1:j);
            g(s+1).YData = sol.y(parameter.N+s,1:j);
        end
        
        g(parameter.N+2).XData = repmat(sol.x(j),1,parameter.N);
        g(parameter.N+2).YData = sol.y(parameter.N+1:2*parameter.N,j);
        
        for s = 1:parameter.N
            g(2*parameter.N+2+s).XData = sol.x(1:j);
            g(2*parameter.N+2+s).YData = sol.y(2*parameter.N+s,1:j);
        end
        
        g(3*parameter.N+3).XData = repmat(sol.x(j),1,parameter.N);
        g(3*parameter.N+3).YData = sol.y(2*parameter.N+1:3*parameter.N,j);
    
        timeP = sol.x(j)/tspan(2);
        TT.XData = [0,timeP,timeP,0,0];
      % drawnow 
      % Capture the plot as an image 
%       frame = getframe(H); 
%       im = frame2im(frame); 
%       [imind,cm] = rgb2ind(im,256); 
%       % Write to the GIF File 
%       imwrite(imind,cm,filename,'gif','WriteMode','append'); 
        frame = getframe(gcf);
        writeVideo(v,frame);
        
    end
    close(v);
    disp('Finished')
end
