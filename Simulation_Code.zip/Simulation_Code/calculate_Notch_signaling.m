function S = calculate_Notch_signaling(sol, parameter)
% calculate [N]/([N]+K) terms for each cell
N = parameter.N;
interaction_M = parameter.interaction_M;
L2 = length(sol.x);
h = parameter.h;
S = zeros(N,L2);

for i = 1:L2
    y = sol.y(:,i);
    Neighbour_D = y(N+1:2*N,1)./parameter.Neighbor_Num;
    Neighbour_J = y(2*N+1:3*N,1)./parameter.Neighbor_Num;
    Neighbour_N = y(3*N+1:4*N,1)./parameter.Neighbor_Num;
    
    D1 = repmat(Neighbour_D',parameter.N,1);
    J1 = repmat(Neighbour_J',parameter.N,1);
    N1 = repmat(Neighbour_N,1,parameter.N);
    N_D_trans = parameter.r21*sum(interaction_M.* (N1.*D1./(N1+D1)),2);
    N_J_trans = parameter.r22*sum(interaction_M.* (N1.*J1./(N1+J1)),2);

    N_D_J_trans = (N_D_trans + N_J_trans);
    
    S(:,i) = N_D_J_trans.^h./(N_D_J_trans.^h + parameter.K2.^h);
    
end
end

