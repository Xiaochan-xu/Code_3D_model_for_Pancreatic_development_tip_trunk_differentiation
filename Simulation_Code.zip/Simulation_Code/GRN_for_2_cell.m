function dydt = GRN_for_2_cell(t, y, Z, parameter)
% model with two time delay
interaction_M = parameter.interaction_M;
N = parameter.N;
dydt = zeros(5*N,1);
% 1:N -> Hes1; N+1:2*N -> Dlata
if parameter.tau_0(1) > 0.5
    ylag1 = Z(:,1);
else
    ylag1 = y;
end
if parameter.tau_0(2) > 0.5
   ylag2 = Z(:,2);% Dll1
%   ylag3 = Z(:,3);% Ptf1a and Jag1
else
    ylag2 = y;
%    ylag3 = y;
end

h = parameter.h;
h0 = parameter.h0;
h1 = parameter.h1;

Neighbour_D = y(N+1:2*N,1)./parameter.Neighbor_Num;
Neighbour_J = y(2*N+1:3*N,1)./parameter.Neighbor_Num;
Neighbour_N = y(3*N+1:4*N,1)./parameter.Neighbor_Num;

N_D_cis =  parameter.r11*Neighbour_D.* Neighbour_N./(Neighbour_D + Neighbour_N).*parameter.Neighbor_Num;
N_J_cis =  parameter.r12*Neighbour_J.* Neighbour_N./(Neighbour_J + Neighbour_N).*parameter.Neighbor_Num;

% signal received and remove N_i removed
N_D_trans =  parameter.r21*Neighbour_N.*(interaction_M*Neighbour_D)./(Neighbour_N+(interaction_M*Neighbour_D));
N_J_trans =  parameter.r22*Neighbour_N.*(interaction_M*Neighbour_J)./(Neighbour_N+(interaction_M*Neighbour_J));
N_D_J_trans = (N_D_trans + N_J_trans);

% give signal and be removed
D_N_trans = parameter.r21*Neighbour_D.*(interaction_M*Neighbour_N)./(Neighbour_D+(interaction_M*Neighbour_N));
J_N_trans = parameter.r22*Neighbour_J.*(interaction_M*Neighbour_N)./(Neighbour_J+(interaction_M*Neighbour_N));

% Hes1
dydt(1:N,1) = parameter.a_H*(parameter.K1^2./(parameter.K1^2+ylag1(1:N,1).^2))...
    .*N_D_J_trans.^h./(N_D_J_trans.^h + parameter.K2.^h)-y(1:N,1)/parameter.tau_h;

% Dll1
 dydt(N+1:2*N,1) = parameter.a_D*(parameter.K3^2./(parameter.K3^2+ylag2(1:N,1).^2))+...
     parameter.a_w*ylag2(4*N+1:5*N,1).^h1./(parameter.K41^h1+ylag2(4*N+1:5*N,1).^h1)...
     - y(N+1:2*N,1)/parameter.tau_d - N_D_cis - D_N_trans;

% Jag1
dydt(2*N+1:3*N,1) = parameter.a_J*y(4*N+1:5*N,1).^h1./(parameter.K42^h1+y(4*N+1:5*N,1).^h1)-y(2*N+1:3*N,1)/parameter.tau_j- N_J_cis - J_N_trans;

% Notch
dydt(3*N+1:4*N,1) = parameter.a_N - N_D_cis - N_J_cis - N_D_trans - N_J_trans - y(3*N+1:4*N)/parameter.tau_n;

% Ptf1a
dydt(4*N+1:5*N,1) = parameter.a_P * (parameter.K5^h0)./(parameter.K5^h0 + y(1:N,1).^h0) - y(4*N+1:5*N,1)/parameter.tau_p;

end
