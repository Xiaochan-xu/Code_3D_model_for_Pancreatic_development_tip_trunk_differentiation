sol = dde23(@(t,y,Z) GRN_for_2_cell(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);               
k1 = find(sol.x>3200,1,'first');
T = sol.x(k1:end);
[caseID, i]
for j = 1:2
    tmp1(i,j) = mean(sol.y(8+j,sol.x>3300));
    [high_P,loc1] = findpeaks(sol.y(j,k1:end));%,'MinPeakProminence',4
    [low_P,loc2] = findpeaks(-sol.y(j,k1:end));%,'MinPeakProminence',4
    low_P = -low_P;
    if ~isempty(high_P)
        tmp(i,2*j-1) = mean(high_P)-mean(low_P);% Amplitude
        tmp(i,2*j) = mean(abs(diff(T(loc1))));% Period
    end
end