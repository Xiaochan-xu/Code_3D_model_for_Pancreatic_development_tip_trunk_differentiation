function Scatter3DPlot(sol, parameter, cell_id)
% code to plot cell fates on 3D structure
Cell_examples = 1:parameter.N;
if ~isempty(cell_id)
    Cell_examples = cell_id;
end
b_size = 0.5;
[X,Y,Z] = sphere;
% Fate: 1, BP; 2, MPC; 3, PAC
x = parameter.ball_color_green;
C1 = zeros(size(X));
for i0=1:length(C1(1,:))
     for j0=1:length(C1(:,1))
       C1(i0,j0,1)=x(i0,1);
       C1(i0,j0,2)=x(i0,2);
       C1(i0,j0,3)=x(i0,3);
    end
end

x = parameter.ball_color_brown;
C2 = zeros(size(X));
for i0=1:length(C2(1,:))
     for j0=1:length(C2(:,1))
       C2(i0,j0,1)=x(i0,1);
       C2(i0,j0,2)=x(i0,2);
       C2(i0,j0,3)=x(i0,3);
    end
end

x = parameter.ball_color_red;
C3 = zeros(size(X));
for i0=1:length(C3(1,:))
     for j0=1:length(C3(:,1))
       C3(i0,j0,1)=x(i0,1);
       C3(i0,j0,2)=x(i0,2);
       C3(i0,j0,3)=x(i0,3);
    end
end

[p1,p2] = find(parameter.interaction_M > 0);
Ax = parameter.cell_center(p1,1)';
Ay = parameter.cell_center(p1,2)';
Az = parameter.cell_center(p1,3)';

Bx = parameter.cell_center(p2,1)';
By = parameter.cell_center(p2,2)';
Bz = parameter.cell_center(p2,3)';

figure('position',[100,800,320,300])
line([Ax;Bx],[Ay;By],[Az;Bz],'color','k','linewidth',0.5)
hold on

% 1, ptf1a low, Hes1 high-->green; 3, ptf1a high, Hes1 low --> red
cell_fate = sol.Statistic(:,4);
for ii = 1:parameter.N
    if cell_fate(ii) == 1
       C = C1;
    elseif cell_fate(ii) == 2
        C = C2;
    else
        C = C3;
    end
    if ~ismember(ii,Cell_examples)
       C(:,:) = 0.6;
       b_size = 0.2;
    else
       b_size = 0.5;
    end
    surf(b_size*X+parameter.cell_center(ii,1),b_size*Y+parameter.cell_center(ii,2),b_size*Z+parameter.cell_center(ii,3),C);
    hold on
    

end
shading interp
view([-50,18])
grid on
axis equal
% xlim([-5,5])
% ylim([-5,5])
% zlim([-5,5.5])
set(gca,'linewidth',1.5,'fontsize',14,'TickLength',[0.02,0.02],'TickDir','out')
set(gca,'xtick',-8:4:8,'xticklabel',-8:4:8,'ytick',-8:4:8,'yticklabel',-8:4:8,'ztick',-8:4:8,'zticklabel',-8:4:8)
xlabel('Dim 1','Rotation',21)
ylabel('Dim 2','Rotation',-15)
zlabel('Dim 3')
end

