function parameter = cell_rearrange(parameter)
   % update cell location based on previous location
    tspan = [0,parameter.dt];
    interaction_M0 = parameter.interaction_M>0;
%      parameter.cell_center = parameter.cell_center + 0.1*(rand(parameter.N,3)-0.5);
    [~,y] = ode45(@(t,y) cell_rearrange0(t,y,interaction_M0, parameter.b, parameter.Vm), tspan, parameter.cell_center);
    parameter.cell_center = [y(end,1:parameter.N)',y(end,parameter.N+1:2*parameter.N)',y(end,2*parameter.N+1:3*parameter.N)'];
end