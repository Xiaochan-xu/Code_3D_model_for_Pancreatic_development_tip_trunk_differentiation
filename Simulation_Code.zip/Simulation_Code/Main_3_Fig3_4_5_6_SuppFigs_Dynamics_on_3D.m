%% Code for Figure3-6: multiple-cell system simulation


%% Figure 3, Figure S3, Simulation of wildtype
% Page 1024pt*1414pt
clc, clear
close all
load('R1_Parameter.mat')
title_str = 'Wildtype';
load([title_str,'.mat'])

Estimate_Hes1_AP_Ptf1a_Mean(sol, parameter,1);
set(gcf,'Position',[10,800,200,450])
% Plot 
Scatter3DPlot(sol, parameter, []);
set(gcf,'Position',[10,800,360,340])


F1 = get(gcf,'CurrentAxes');
axChildren = get(F1,'Children');

CellFateDistribute(sol, parameter);
subplot(1,2,2)
copyobj(axChildren,gca)
zlim([-3,3])
xlabel('Dim1','Rotation',0)
ylabel('Dim2','Rotation',90)
axis equal
xlim([-6,7])
ylim([-6,7])
title('Dim3 \in [-3, 3]','fontweight','normal')
view(180,90)
box off
set(gca,'xtick',-5:5:5,'ytick',-5:5:5,'linewidth',1.5,'fontsize',14,'TickLength',[0.03,0.03],'TickDir','out')
set(gcf,'Position',[10,800,700,300])

% example for three fates
cell_id = [115,109,95];
Plot_Gene_Dynamic(sol, parameter, cell_id, [0,2200],0)
set(gcf,'Position',[10,800,380,350])
%Scatter3DPlot(sol, parameter, cell_id);

% example1 for two BP pair
cell_id = [119,119,103];
Plot_Gene_Dynamic(sol, parameter, cell_id, [2800,3200],0)
set(gcf,'Position',[10,800,300,350])
Scatter3DPlot(sol, parameter, cell_id);
set(gcf,'Position',[10,800,300,300])
% axis off

% example2 for two MPC pair
cell_id = [59,59,23];
Plot_Gene_Dynamic(sol, parameter, cell_id, [2800,3200],0)
set(gcf,'Position',[10,800,300,350])
Scatter3DPlot(sol, parameter, cell_id);
set(gcf,'Position',[10,800,300,300])
axis off

% Plot neighbour number
S_marker = 30;

figure('position',[100,500,550,300])
for ii = 1:3
    k_P = find(sol.Statistic(:,4) == ii);
    ww = 1/(length(k_P)-1);
    rr_ww = -0.5:ww:0.5;        
    dot_color = [0.4,0.4,1];
    x0 = 5*ii-3;
    %scatter(x0+0.6*rr_ww,parameter.Inner_Neighbor_Num(k_P,1),S_marker,dot_color,'o','filled')
    %alpha(0.5) 
    hold on
    
    scatter(x0+0.6*rr_ww,parameter.Inner_Neighbor_Num(k_P,1),S_marker,dot_color,'o','filled','linewidth',1)
    MM_SD = [mean(parameter.Inner_Neighbor_Num(k_P,1)), std(parameter.Inner_Neighbor_Num(k_P,1))];
    plot([x0-0.5,x0+0.5],[MM_SD(1),MM_SD(1)],'linewidth',1.5,'color',[0,0,1])
    errorbar(x0,MM_SD(1),MM_SD(2),'linewidth',1.5,'color',[0,0,1],'CapSize',10)
    
    x0 = 5*ii-2;
    dot_color = [0.5,0.5,0.5];
    %scatter(x0+0.6*rr_ww,parameter.Inner_Neighbor_Num(k_P,2)-parameter.Inner_Neighbor_Num(k_P,1),S_marker,dot_color,'o','filled')
    %alpha(0.5) 
    hold on
    
    scatter(x0+0.6*rr_ww,parameter.Inner_Neighbor_Num(k_P,2)-parameter.Inner_Neighbor_Num(k_P,1),S_marker,dot_color,'o','filled','linewidth',1)
    MM_SD = [mean(parameter.Inner_Neighbor_Num(k_P,2)-parameter.Inner_Neighbor_Num(k_P,1)),...
        std(parameter.Inner_Neighbor_Num(k_P,2)-parameter.Inner_Neighbor_Num(k_P,1))];
    plot([x0-0.5,x0+0.5],[MM_SD(1),MM_SD(1)],'linewidth',1.5,'color','k')
    errorbar(x0,MM_SD(1),MM_SD(2),'linewidth',1.5,'color','k','CapSize',10)
    
    
    x0 = 5*ii-1;
    dot_color = [0.7,0.3,0.3];
    %scatter(x0+0.6*rr_ww,parameter.Inner_Neighbor_Num(k_P,2)-parameter.Inner_Neighbor_Num(k_P,1),S_marker,dot_color,'o','filled')
    %alpha(0.5) 
    hold on
    
    scatter(x0+0.6*rr_ww,parameter.Inner_Neighbor_Num(k_P,2),S_marker,dot_color,'o','filled','linewidth',1)
    MM_SD = [mean(parameter.Inner_Neighbor_Num(k_P,2)),...
        std(parameter.Inner_Neighbor_Num(k_P,2))];
    plot([x0-0.5,x0+0.5],[MM_SD(1),MM_SD(1)],'linewidth',1.5,'color','k')
    errorbar(x0,MM_SD(1),MM_SD(2),'linewidth',1.5,'color','k','CapSize',10)
        
    
end
set(gca,'xtick',5*[1:3]-2,'xticklabel',{'BP','MPC','PAC'})
set(gca,'ytick',0:5:15)
ylim([-3,18])
box off
plot([5.5,5.5],[-3,18],'k-','linewidth',1)
plot([10.5,10.5],[-3,18],'k-','linewidth',1)
set(gca,'linewidth',1.5,'fontsize',14,'TickLength',[0.03,0.03],'TickDir','out')
xlim([0.25,15+0.75])
xlabel(' ')
ylabel('Number of neighbours')
text(17,16,'Epithelial','color',[0.4,0.4,1],'fontsize',14)
text(17,14,'Mesenchymal','color',[0.2,0.2,0.2],'fontsize',14)
text(17,12,'Total','color',[0.7,0.3,0.3],'fontsize',14)
h = gca;
h.Position(3) = 0.8*h.Position(3);
box off 
    
% k = find(parameter.interaction_M(103,:)==1);
% k(find(sol.Statistic(k,4)==1))
%% Figure S3: Fixed number of neighbours
load('Fixed nei_num.mat')
Estimate_Hes1_AP_Ptf1a_Mean(sol, parameter,1);
set(gcf,'Position',[10,800,250,250])

Scatter3DPlot(sol, parameter, []);
set(gcf,'Position',[10,800,360,340])

F1 = get(gcf,'CurrentAxes');
axChildren = get(F1,'Children');

CellFateDistribute(sol, parameter);
subplot(1,2,2)
copyobj(axChildren,gca)
zlim([-3,3])
xlabel('Dim1','Rotation',0)
ylabel('Dim2','Rotation',90)
axis equal
xlim([-6,7])
ylim([-6,7])
title('Dim3 \in [-3, 3]','fontweight','normal')
view(180,90)
box off
set(gca,'xtick',-5:5:5,'ytick',-5:5:5,'linewidth',1.5,'fontsize',14,'TickLength',[0.03,0.03],'TickDir','out')
set(gcf,'Position',[10,800,700,250])

%% Figure 4: Simulation of DAPT and MLN4924 
markercolor = lines(3);
for caseID = 1:2
load('R1_Parameter.mat')
switch caseID
    case 1
        % DAPT
        title_str = 'DAPT';
        Ecolor = markercolor(2,:);
        Emarker = 's';
        xx = [0,25];
    case 2
        % MLN4924
        title_str = 'MLN4924';
        Ecolor = markercolor(3,:);
        Emarker = '^';
        xx = [0,13.5];
end
load([title_str,'.mat'])
Estimate_Hes1_AP_Ptf1a_Mean(sol, parameter,1);

tmp = sol;
load('Wildtype.mat')
figure('Position',[100,500,200,200])
plot(sol.Statistic(:,3),sol.Statistic(:,1),'o','color',markercolor(1,:),'linewidth',1.5,'MarkerSize', 8)
hold on
plot(tmp.Statistic(:,3),tmp.Statistic(:,1),Emarker,'color',Ecolor,'linewidth',1.5,'MarkerSize', 8)
set(gca,'box','off','linewidth',1.5,'fontsize',14,'TickLength',[0.03,0.03],'TickDir','out')
if caseID == 1
set(gca,'xtick',0:10:25,'xticklabel',0:10:25,'ytick',0:3:6,'yticklabel',0:3:6)
else
  set(gca,'xtick',0:5:25,'xticklabel',0:5:25,'ytick',0:3:6,'yticklabel',0:3:6)
end  
xlabel('Ptf1a')
ylabel('Amplitute of Hes1')
box off
xlim(xx)
ylim([-0,7])
legend('DMSO',title_str)
legend('box','off','fontAngle','italic')
end


% Plot amplitude of Hes1
Amp_Hes1_Wildtype_DAPT_MLN4924 = cell(3,1);
figure('Position',[100,500,200,200])
S_marker = 15;
for ii = 1:3
    switch ii
        case 1
            title_str = 'DMSO';
            load('Wildtype.mat')
            Emarker = 'o';
            k_P = find(sol.Statistic(:,4) ~= 3);
        case 2
            title_str = 'DAPT';
            load([title_str,'.mat'])
            Emarker = 's';
            k_P = find(sol.Statistic(:,4) == 1);
        case 3
            title_str = 'MLN4924';
            load([title_str,'.mat'])
            Emarker = '^';
            k_P = find(sol.Statistic(:,4) ~= 0);
    end
    
    Amp_Hes1_Wildtype_DAPT_MLN4924{ii,1} = sol.Statistic(k_P,1);
    
    ww = 1/(length(k_P)-1);
    rr_ww = -0.5:ww:0.5;        
    dot_color = [0,0.45,0.75];
    x0 = ii; 
    scatter(x0+0.6*rr_ww,sol.Statistic(k_P,1),S_marker,dot_color,Emarker,'filled')
    alpha(0.5)
    hold on
    
    scatter(x0+0.6*rr_ww,sol.Statistic(k_P,1),S_marker,dot_color,Emarker,'linewidth',1)
    MM_SD = [mean(sol.Statistic(k_P,1)), std(sol.Statistic(k_P,1))];
    plot([x0-0.5,x0+0.5],[MM_SD(1),MM_SD(1)],'linewidth',1.5,'color',[0,0,0])
    errorbar(x0,MM_SD(1),MM_SD(2),'linewidth',1.5,'color',[0,0,0],'CapSize',10)
end

% save Amp_Hes1_Wildtype_DAPT_MLN4924 Amp_Hes1_Wildtype_DAPT_MLN4924
% csvwrite('Amp_Hes1_DMSO.csv', Amp_Hes1_Wildtype_DAPT_MLN4924{1,1})
% csvwrite('Amp_Hes1_DAPT.csv', Amp_Hes1_Wildtype_DAPT_MLN4924{2,1})
% csvwrite('Amp_Hes1_MLN4924.csv', Amp_Hes1_Wildtype_DAPT_MLN4924{3,1})

set(gca,'xtick',1:3,'xticklabel',{'DMSO','DAPT','MLN4924'})
set(gca,'ytick',0:5:15)
ylim([0,12])
set(gca,'linewidth',1.5,'fontsize',14,'TickLength',[0.03,0.03],'TickDir','out')
xlim([0.25,3+0.75])
xlabel(' ')
ylabel('Amplitude of Hes1')
box off 

%
title_str = 'DAPT';
load([title_str,'.mat'])
tmp = sol.Statistic(:,4);
sol.Statistic(:,4) = 3;
sol.Statistic(tmp==1,4) = 2;
Scatter3DPlot(sol, parameter, []);
set(gcf,'Position',[100,800,248,213])

title_str = 'MLN4924';
load([title_str,'.mat'])
tmp = sol.Statistic(:,1);
sol.Statistic(:,4) = 1;
sol.Statistic(tmp<3,4) = 2;
Scatter3DPlot(sol, parameter, []);
set(gcf,'Position',[100,800,248,213])


%% Figure 5: Simulation of Dll1 deficient and Jag1 deficient
markercolor = lines(3);

% Figure 3C from Palle's paper, PAC, BP, MPC
E_str = {'Wild-type','Dll1-half','Dll1-0', 'Jag1-half','Jag1-0'};
E_MPC = cell(5,1);
E_MPC{1,1} = [11.1,14.0,13.7,9.4,8.5];
E_MPC{2,1} = [11.0,8.1,7.9,4.8];
E_MPC{3,1} = [4.2,6.5,2.5,9.2];
E_MPC{4,1} = [33.3,24.9,40.3];
E_MPC{5,1} = [42.8,59.3,49.3];

for i = 1:5
E_cellP_mean(i,1) = mean(E_MPC{i,1}); 
E_cellP_sd(i,1) = std(E_MPC{i,1});
end
CLabel = {'BP','MPC','PAC'};
S_cellP_mean = zeros(5,3);
for caseID = 1:5
    switch caseID
        case 1
            load('Wildtype.mat')
        case 2
            load('Dll1 Partial_deficient.mat')
            k1 = find(sol.Statistic(:,1)<3);
            k2 = find(sol.Statistic(:,4) == 1);
            kk = intersect(k1,k2);
            sol.Statistic(kk,4) = 2;
            save('Dll1 Partial_deficient.mat','sol')
            
        case 3
            load('Dll1 deficient.mat')    
        case 4
            load('Jag1 Partial_deficient.mat')
            k1 = find(sol.Statistic(:,1)<3.2);
            k2 = find(sol.Statistic(:,4) == 1);
            kk = intersect(k1,k2);
            sol.Statistic(kk,4) = 2;
            save('Jag1 Partial_deficient.mat','sol')
        case 5
            load('Jag1 deficient.mat')
            k1 = find(sol.Statistic(:,1)<3);
            k2 = find(sol.Statistic(:,4) == 1);
            kk = intersect(k1,k2);
            sol.Statistic(kk,4) = 2;
            save('Jag1 deficient.mat','sol')      
    end 
    % Plot
            R = sol.Statistic;
            figure('position',[100,500,220,220])
            for i = 1:3
                plot(R(R(:,4)==i,3),R(R(:,4)==i,1),'o','markersize',8,'color',parameter.fate_colors(i,:),'linewidth',1.5)
                hold on   
            end
            dxy = [0.5,0;0.5,0.5;-1.5,0.5];
            for i = 1:3
                if any(R(:,4)==i)
                    S_cellP_mean(caseID,i) = round(1000*sum(R(:,4)==i)/parameter.N)/10;
                    center_text = mean(R(R(:,4)==i,[1,3]),1);
                    text(center_text(2)+dxy(i,1), center_text(1)+dxy(i,2), [CLabel{i}, ' (', num2str(S_cellP_mean(caseID,i)),'%)'], 'fontsize', 14)
                end
            end
            set(gca,'linewidth',1.5,'fontsize',14,'TickLength',[0.03,0.03],'TickDir','out')
            xlabel('Ptf1a')
            ylabel('Amplitute of Hes1')
            box off
            set(gca,'Xtick',0:5:40,'ytick',0:3:30)

end

%% barPlot
figure('Position',[100,800,280,230])
errorbar(3*[1:5]-2, E_cellP_mean(:,1), E_cellP_sd(:,1),'linewidth',1.5,'LineStyle','none','color',[0.7,0.3,0.3])
hold on
for i = 1:5
     h(1) = bar(3*i-2,E_cellP_mean(i,1), 'FaceColor',[0.8,0.8,0.8],'EdgeColor',[0,0,0],'linewidth',1.5);
     hold on
     ww = 1/(length(E_MPC{i,1})-1);
     rr_ww = -0.5:ww:0.5;
     scatter(3*i-2-0.5*rr_ww,E_MPC{i,1},20,'k','o','filled')
     h(2) = bar(3*i-1,S_cellP_mean(i,2), 'FaceColor',[0,0.45,0.75],'EdgeColor',[0,0.45,0.75],'linewidth',1.5);
end
ylim([-1,80])
set(gca,'ytick',0:20:100,'xtick',3*[1:5]-1.5,'xticklabel',{'R26^{Yfp/Yfp}','Dll1^{f/f}','Dll1^{\DeltaFoxa2}','Jag11^{\DeltaFoxa2/+}','Jag11^{\DeltaFoxa2/-}'})
set(gca,'box','off','linewidth',1.5,'fontsize',14,'TickLength',[0.03,0.03],'TickDir','out')
ylabel('% of total')
legend(h,'Experiment','Simulation','Location','northwest','box','off');
title('MPC proportion','FontWeight','normal')

%%
title_str = 'Dll1 deficient';
load([title_str,'.mat'])
tmp = sol.Statistic(:,4);
sol.Statistic(tmp==2,4) = 1;
Scatter3DPlot(sol, parameter, []);
set(gcf,'Position',[100,800,320,250])

title_str = 'Jag1 deficient';
load([title_str,'.mat'])
Scatter3DPlot(sol, parameter, []);
set(gcf,'Position',[100,800,320,250])

%%

cell_id = [115,109,95];
load('Wildtype.mat')
Plot_Gene_Dynamic(sol, parameter, cell_id, [2800,3400],0)
set(gcf,'Position',[100,800,280,280])

load('Dll1 deficient.mat')
Plot_Gene_Dynamic(sol, parameter, cell_id, [2800,3400],0)
set(gcf,'Position',[100,800,280,280])

load('Jag1 deficient.mat')
Plot_Gene_Dynamic(sol, parameter, cell_id, [2800,3400],0)
set(gcf,'Position',[100,800,280,280])

%% SuppFigure 4e: Dll1 delay effects in multiple-cell model
Amp_4 = cell(4,1);
bin = 150;
for caseID = 1:4
    caseID
    switch caseID
        case 1
            title_str = 'Wildtype';
        case 2
            title_str = 'Dll1 delay';
        case 3
            title_str = 'Jag1 deficient';
        case 4
            title_str = 'Dll1 delay wo Jag1';
    end
    load([title_str,'.mat'])
    
    R = zeros(parameter.N,16);
    for j = 1:16
        xx_range = [bin*(j-1),bin*j]; % Time interval used to estimate
        k1 = find(sol.x>xx_range(1),1,'first');
        k2 = find(sol.x<xx_range(2),1,'last');
        for i = 1:parameter.N
           R(i,j) = max(sol.y(i,k1:k2))-min(sol.y(i,k1:k2));
        end
    end
    Amp_4{caseID,1} = R;
       
end
%
figure('Position',[10,800,350,250])
cdot = lines(2);
marks = {'s','o'};
for i = 1:2
    R1 = Amp_4{2*i-1,1};
    R2 = Amp_4{2*i,1};
    R0 = R2-R1;
    mm = mean(R0,1);
    sdd = std(R0,[],1);
    errorbar(-0.5+[1:size(R0,2)],mm,sdd,'linewidth',1,'color',cdot(i,:))
    hold on
%     for j = 1:parameter.N
%        plot(1:size(R0,2),R0(j,:),'.-','color',cdot(i,:),'linewidth',1)
%     end
    h(i) = plot(-0.5+[1:size(R0,2)],mm,'-','marker',marks{i},'color',cdot(i,:),...
        'MarkerFaceColor',cdot(i,:),'linewidth',1,'markersize',8);
    plot([0,size(R0,2)],[0,0],'k--','linewidth',1)
end
legend(h,'With Jag1','Without Jag1')
set(gca,'box','off','linewidth',1.5,'fontsize',14,'TickLength',[0.03,0.03],'TickDir','out')
set(gca,'xtick',0:5:15,'xticklabel',bin*([0:5:15]))
xlabel('Time')
xlim([0,16])
ylabel({'Difference of amplitude (Hes1)';'Caused by Dll1 delay'})
title('Delay in Dll1 transcription (6 min)','fontweight','normal')
%% Figure s4f

title_str = 'Dll1 delay';
load('Dll1 delay.mat');% 6 min
Estimate_Hes1_AP_Ptf1a_Mean(sol, parameter,1);

tmp = sol;
markercolor = lines(3);

figure('Position',[100,500,200,200])
load('Wildtype.mat')
plot(sol.Statistic(:,3),sol.Statistic(:,1),'s','color',markercolor(1,:),'linewidth',1.5,'MarkerSize', 8)
hold on
plot(tmp.Statistic(:,3),tmp.Statistic(:,1),'o','color',markercolor(3,:),'linewidth',1.5,'MarkerSize', 8)

set(gca,'box','off','linewidth',1.5,'fontsize',14,'TickLength',[0.03,0.03],'TickDir','out')
set(gca,'xtick',0:3:12,'xticklabel',0:3:12,'ytick',0:3:6,'yticklabel',0:3:6)
xlabel('Ptf1a')
ylabel('Amplitute of Hes1')
box off
xlim([-0,13])
ylim([-0,6.5])
legend('Wild-type','Type2 Dll1 mutant')
legend('box','off','fontAngle','italic')

Scatter3DPlot(tmp, parameter, []);
set(gcf,'Position',[100,800,280,250])

cell_id = [115,109,95];
Plot_Gene_Dynamic(tmp, parameter, cell_id, [2800,3200],0)
Plot_Gene_Dynamic(tmp, parameter, cell_id, [0,2000],0)
%% Figure S4i

load('R1_Parameter.mat')
S = 0:3:30;
S(1) = 0.1;
Cell_fate_frac = zeros(length(S),3);% delay, MPC frac, BP frac, Hes1 period
for i = 1:length(S)
    close all
    S(i)
parameter.tau_0(2) = S(i);
sol = dde23(@(t,y,Z) Notch_Delta_Hes1_GRN_Hes1_Delta_Jag1_Notch(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
sol.Statistic = Estimate_Hes1_AP_Ptf1a_Mean(sol, parameter, 0);
k1 = find(sol.Statistic(:,1)<3);
k2 = find(sol.Statistic(:,3)<2);
kk = intersect(k1,k2);
sol.Statistic(kk,4) = 2;
BP_fra = sum(sol.Statistic(:,4)==1)/parameter.N*100;
MPC_frac = sum(sol.Statistic(:,4)==2)/parameter.N*100;
if S(i) > 20
   MPC_frac = 0; 
end
Cell_fate_frac(i,1:3) = [S(i),MPC_frac, BP_fra];
end
Cell_fate_frac(1,1) = 0;

figure('Position',[100,500,350,250])

hold on

plot(Cell_fate_frac(:,1),Cell_fate_frac(:,2),'.-','markersize',15,'color',parameter.fate_colors(2,:),'linewidth',1.5)
plot(Cell_fate_frac(:,1),100-Cell_fate_frac(:,2)-Cell_fate_frac(:,3),'.-','markersize',15,'color',parameter.fate_colors(3,:),'linewidth',1.5)

set(gca,'box','off','linewidth',1.5,'fontsize',14,'TickLength',[0.02,0.02],'TickDir','out')
set(gca,'xtick',0:3:S(end),'xticklabel',0:3:S(end),'ytick',0:5:100,'yticklabel',0:5:100)
xlabel('Delay (min)')
ylabel('% of PAC/MPC fates')

box off
yyaxis right
plot(Cell_fate_frac(:,1),Cell_fate_frac(:,3),'.-','markersize',15,'color',parameter.fate_colors(1,:),'linewidth',1.5)
ax = gca;
ax.YAxis(2).Color = parameter.fate_colors(1,:);
ax.YTick = 0:5:100;
ax.YLim = [60,85];
legend('MPC','PAC','BP')
legend('box','off')
ylabel('% of BP fate')
%% Figure 6: bifurcation of cis interaction

load('R1_Parameter.mat')
r10 = parameter.r11;

S = 0:0.02:0.46;
Hes1_A = zeros(parameter.N,length(S));% r11,r12; Amplitude of Hes1; Ptf1a expression
Ptf1a = zeros(parameter.N,length(S));
Hes1_A_J = zeros(parameter.N,length(S));%
Ptf1a_J = zeros(parameter.N,length(S));
for i = 24:length(S)
    S(i)
    close all
    parameter.r11 = S(i);
    parameter.r12 = S(i);
    sol = dde23(@(t,y,Z) Notch_Delta_Hes1_GRN_Hes1_Delta_Jag1_Notch(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
    sol.Statistic = Estimate_Hes1_AP_Ptf1a_Mean(sol, parameter,0);
    Hes1_A(:,i) = sol.Statistic(:,1);
    Ptf1a(:,i) = sol.Statistic(:,3);
end

parameter.a_J = 0;
for i = 1:length(S)
    S(i)
    close all
    parameter.r11 = S(i);
    parameter.r12 = S(i);
    sol = dde23(@(t,y,Z) Notch_Delta_Hes1_GRN_Hes1_Delta_Jag1_Notch(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
    sol.Statistic = Estimate_Hes1_AP_Ptf1a_Mean(sol, parameter,0);
    Hes1_A_J(:,i) = sol.Statistic(:,1);
    Ptf1a_J(:,i) = sol.Statistic(:,3);
end

%% Figure 6b and 6e Plot with heatmap
close all
S = 0:0.02:0.44;

for caseID = 1:2
    caseID
    figure('Position',[100,500,350,200])
    cm = redbluecmap(11);
    cm = cm(6:-1:1,:);
    cm(1,:) = [1,1,1];
    markersize = 10;
    xx = 0:0.08:S(end);
    yy = 0:0.5:7;
    M = zeros(length(yy),length(S));
    dot_color = [82,101,174]/255;
    hold on
    for i = 1:length(S)
        if caseID == 1
            tmp = hist(Hes1_A(:,i),yy);
        else
            tmp = hist(Hes1_A_J(:,i),yy);
        end
        M(:,i) = tmp';
    end
    hold on
    imagesc(M,[0,150])
    colormap(cm)
    
    for i = 1:parameter.N
        if caseID == 1
            tmp = discretize(Hes1_A(i,1:length(S)),yy-0.25);
        else
            tmp = discretize(Hes1_A_J(i,1:length(S)),yy-0.25);
        end
        plot(tmp,'.','markersize',markersize,'color',dot_color)
    end
    
    xlim([0,length(S)+1])
    ylim([-0.5,15])
    
    %tmp = find(S==r10);
    tmp = 13.5;
    y0 = ylim;
    
    plot([tmp,tmp],y0,'k--','linewidth',1.5)
    h0 = gca;
    
    h = colorbar;
    h.Position = [0.83,0.3,0.035,0.4];
    h.Label.String = 'Number of cells';
    h.Label.Position(1) = -2;
    h0.Position = [0.14,0.3,0.6,0.6];
    
    set(gca,'box','off','YDir','normal','linewidth',1.5,'fontsize',14,'TickLength',[0.02,0.02],'TickDir','out')
    set(gca,'xtick',1:5:length(S),'xticklabel',S(1:5:length(S)),'ytick',1:6:length(yy),'yticklabel',yy(1:6:length(yy)))
    xlabel('{\itCis}-interaction rate (\gamma_1)')
    ylabel('Amplitude of Hes1')

    % Plot Ptf1a
    cm = redbluecmap(11);
    cm = cm(6:-1:1,:);
    cm(1,:) = [1,1,1];
    markersize = 10;
    yy = 0:1:24;
    M = zeros(length(yy),length(S));
    dot_color = [82,101,174]/255;
    for i = 1:length(S)
        if caseID == 1
            tmp = hist(Ptf1a(:,i),yy);
        else
            tmp = hist(Ptf1a_J(:,i),yy);
        end
        M(:,i) = tmp';
    end
    
    figure('Position',[100,500,350,200])
    hold on
    imagesc(M,[0,150])
    colormap(cm)
    
    for i = 1:parameter.N
        if caseID == 1
            tmp = discretize(Ptf1a(i,1:length(S)),yy-0.5);
        else
            tmp = discretize(Ptf1a_J(i,1:length(S)),yy-0.5);
        end
        plot(tmp,'.','markersize',markersize,'color',dot_color)
    end
    
    xlim([0,length(S)+1])
    ylim([-0.5,24])
    
   % tmp = find(S==r10);
    tmp = 13.5;
    y0 = ylim;
    plot([tmp,tmp],y0,'k--','linewidth',1.5)
    h0 = gca;
    
    h = colorbar;
    h.Position = [0.85,0.3,0.035,0.4];
    h.Label.String = 'Number of cells';
    h.Label.Position(1) = -2;
    h0.Position = [0.16,0.3,0.6,0.6];
    
    set(gca,'box','off','YDir','normal','linewidth',1.5,'fontsize',14,'TickLength',[0.02,0.02],'TickDir','out')
    set(gca,'xtick',1:5:length(S),'xticklabel',S(1:5:length(S)),'ytick',1:6:length(yy),'yticklabel',yy(1:6:length(yy)))
    xlabel('{\itCis}-interaction rate (\gamma_1)')
    ylabel('Ptf1a')
    
end

%%
S = 0:0.02:0.46;
colors = lines(3);
figure('Position',[100,500,250,250])
j0 = 9;
plot(Ptf1a(:,j0),Hes1_A(:,j0),'o','MarkerFaceColor',colors(1,:))
hold on
plot(Ptf1a_J(:,j0),Hes1_A_J(:,j0),'s','MarkerFaceColor',colors(3,:))
title(['\gamma_1 = ',num2str(S(j0))],'FontWeight','normal')
set(gca,'box','off','YDir','normal','linewidth',1.5,'fontsize',14,'TickLength',[0.02,0.02],'TickDir','out')
legend('Wild-type','Jag1 deficient')
xlabel('Ptf1a')
ylabel('Amplitude of Hes1')

figure('Position',[100,500,250,250])
j0 = 16;
plot(Ptf1a(:,j0),Hes1_A(:,j0),'o','MarkerEdgeColor',colors(1,:),'MarkerFaceColor',colors(1,:))
hold on
plot(Ptf1a_J(:,j0),Hes1_A_J(:,j0),'s','MarkerEdgeColor',colors(2,:),'MarkerFaceColor',colors(3,:))

title(['\gamma_1 = ',num2str(S(j0))],'FontWeight','normal')
set(gca,'box','off','YDir','normal','linewidth',1.5,'fontsize',14,'TickLength',[0.02,0.02],'TickDir','out')
legend('Wild-type','Jag1 deficient') 
xlabel('Ptf1a')
ylabel('Amplitude of Hes1')


figure('Position',[100,500,250,250])
j0 = 20;
plot(Ptf1a(:,j0),Hes1_A(:,j0),'o','MarkerEdgeColor',colors(1,:),'MarkerFaceColor',colors(1,:))

hold on
plot(Ptf1a_J(:,j0),Hes1_A_J(:,j0),'s','MarkerEdgeColor',colors(2,:),'MarkerFaceColor',colors(3,:))

title(['\gamma_1 = ',num2str(S(j0))],'FontWeight','normal')
set(gca,'box','off','YDir','normal','linewidth',1.5,'fontsize',14,'TickLength',[0.02,0.02],'TickDir','out')
legend('Wild-type','Jag1 deficient') 
xlabel('Ptf1a')
ylabel('Amplitude of Hes1')

figure('Position',[100,500,250,250])
j0 = 17;
plot(Ptf1a(:,j0),Hes1_A(:,j0),'o','MarkerEdgeColor',colors(1,:),'MarkerFaceColor',colors(1,:))
hold on
plot(Ptf1a_J(:,j0),Hes1_A_J(:,j0),'s','MarkerEdgeColor',colors(2,:),'MarkerFaceColor',colors(3,:))

title(['\gamma_1 = ',num2str(S(j0))],'FontWeight','normal')
set(gca,'box','off','YDir','normal','linewidth',1.5,'fontsize',14,'TickLength',[0.02,0.02],'TickDir','out')
legend('Wild-type','Jag1 deficient') 
xlabel('Ptf1a')
ylabel('Amplitude of Hes1')
%%
load('R1_Parameter.mat')
r10 = parameter.r11;
parameter.a_J = 0;
parameter.r11 = 0.38;
parameter.r12 = 0.38;
parameter.a_J = 1.2;
sol = dde23(@(t,y,Z) Notch_Delta_Hes1_GRN_Hes1_Delta_Jag1_Notch(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
sol.Statistic = Estimate_Hes1_AP_Ptf1a_Mean(sol, parameter);
S = calculate_Notch_signaling(sol,parameter);
sol.S = S;

Plot_Gene_Dynamic(sol, parameter, [1,3], [2800,3200],0)
set(gcf,'Position',[100,500,300,230])

figure,
subplot(2,1,1)
title('Wild-type, \gamma_1 = 0.3','FontWeight','normal')
set(gca,'box','off','YDir','normal','linewidth',1.5,'fontsize',14,'TickLength',[0.02,0.02],'TickDir','out')

subplot(2,1,1)
title('{\itJag1 dificient}, \gamma_1 = 0.48','FontWeight','normal')
set(gca,'box','off','YDir','normal','linewidth',1.5,'fontsize',14,'TickLength',[0.02,0.02],'TickDir','out')
%% Figure 6e–6f
for caseID = 2:2
    load('R1_Parameter.mat')
    caseID
    switch caseID
        case 1
            parameter.r11 = 0.2;
            parameter.r12 = 0.2;
            parameter.a_J = 1;
            sol = dde23(@(t,y,Z) Notch_Delta_Hes1_GRN_Hes1_Delta_Jag1_Notch(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
            sol.Statistic = Estimate_Hes1_AP_Ptf1a_Mean(sol, parameter,0);
            W1 = sol;
        case 2
            parameter.r11 = 0.2;
            parameter.r12 = 0.2;
            %parameter.a_D = 1.0;parameter.a_w = 1.2; 
            parameter.a_J = 4;
            sol = dde23(@(t,y,Z) Notch_Delta_Hes1_GRN_Hes1_Delta_Jag1_Notch(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
            sol.Statistic = Estimate_Hes1_AP_Ptf1a_Mean(sol, parameter,0);
            W2 = sol;
        case 3
            parameter.r11 = 0.2;
            parameter.r12 = 0.2;
            parameter.a_J = 0;
            sol = dde23(@(t,y,Z) Notch_Delta_Hes1_GRN_Hes1_Delta_Jag1_Notch(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
            sol.Statistic = Estimate_Hes1_AP_Ptf1a_Mean(sol, parameter,0);
            W3 = sol;
        case 4
            parameter.r11 = 0.38;
            parameter.r12 = 0.38;
            parameter.a_J = 1;
            sol = dde23(@(t,y,Z) Notch_Delta_Hes1_GRN_Hes1_Delta_Jag1_Notch(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
            sol.Statistic = Estimate_Hes1_AP_Ptf1a_Mean(sol, parameter,0);
            W4 = sol;
        case 5
            parameter.r11 = 0.38;
            parameter.r12 = 0.38;
            parameter.a_J = 4;
            sol = dde23(@(t,y,Z) Notch_Delta_Hes1_GRN_Hes1_Delta_Jag1_Notch(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
            sol.Statistic = Estimate_Hes1_AP_Ptf1a_Mean(sol, parameter,0);
            W5 = sol;
         case 6
            parameter.r11 = 0.38;
            parameter.r12 = 0.38;
            parameter.a_J = 0;
            sol = dde23(@(t,y,Z) Notch_Delta_Hes1_GRN_Hes1_Delta_Jag1_Notch(t,y, Z, parameter), parameter.tau_0, parameter.history_Z, parameter.tspan, parameter.options);
            sol.Statistic = Estimate_Hes1_AP_Ptf1a_Mean(sol, parameter,0);
            W6 = sol; 
    end
end

%%
colors = lines(3);    
figure('Position',[100,500,250,250])  
plot(W1.Statistic(:,3),W1.Statistic(:,1),'o','MarkerEdgeColor',[0.2,0.2,0.8],'MarkerFaceColor',colors(1,:))
hold on
plot(W2.Statistic(:,3),W2.Statistic(:,1),'s','MarkerEdgeColor',colors(2,:),'MarkerFaceColor',colors(3,:))
title('\gamma_1 = 0.2','FontWeight','normal')
set(gca,'box','off','YDir','normal','linewidth',1.5,'fontsize',14,'TickLength',[0.02,0.02],'TickDir','out')
legend('Wild-type','Jag1 increased')
xlabel('Ptf1a')
ylabel('Amplitude of Hes1')

figure('Position',[100,500,250,250])  
plot(W1.Statistic(:,3),W1.Statistic(:,1),'o','MarkerEdgeColor',[0.2,0.2,0.8],'MarkerFaceColor',colors(1,:))
hold on
plot(W3.Statistic(:,3),W3.Statistic(:,1),'s','MarkerEdgeColor','k','MarkerFaceColor',colors(2,:))
title('\gamma_1 = 0.2','FontWeight','normal')
set(gca,'box','off','YDir','normal','linewidth',1.5,'fontsize',14,'TickLength',[0.02,0.02],'TickDir','out')
legend('Wild-type','Jag1 deficient')
xlabel('Ptf1a')
ylabel('Amplitude of Hes1')



figure('Position',[100,500,250,250])  
plot(W4.Statistic(:,3),W4.Statistic(:,1),'o','MarkerEdgeColor',[0.2,0.2,0.8],'MarkerFaceColor',colors(1,:))
hold on
plot(W5.Statistic(:,3),W5.Statistic(:,1),'s','MarkerEdgeColor',colors(2,:),'MarkerFaceColor',colors(3,:))
title('\gamma_1 = 0.38','FontWeight','normal')
set(gca,'box','off','YDir','normal','linewidth',1.5,'fontsize',14,'TickLength',[0.02,0.02],'TickDir','out')
legend('Wild-type','Jag1 increased')
xlabel('Ptf1a')
ylabel('Amplitude of Hes1')

figure('Position',[100,500,250,250])  
plot(W4.Statistic(:,3),W4.Statistic(:,1),'o','MarkerEdgeColor',[0.2,0.2,0.8],'MarkerFaceColor',colors(1,:))
hold on
plot(W6.Statistic(:,3),W6.Statistic(:,1),'s','MarkerEdgeColor','k','MarkerFaceColor',colors(2,:))

title('\gamma_1 = 0.38','FontWeight','normal')
set(gca,'box','off','YDir','normal','linewidth',1.5,'fontsize',14,'TickLength',[0.02,0.02],'TickDir','out')
legend('Wild-type','Jag1 deficient')
xlabel('Ptf1a')
ylabel('Amplitude of Hes1')
%% Remove cis-interaction specifically on Jag1 or Dll1
for caseID = 1:4
    switch caseID
        case 1
            title_str = 'Remove Cis_Dll1';
        case 2
            title_str = 'Remove Trans_Dll1';
        case 3
            title_str = 'Remove Cis_Jag1';
        case 4
            title_str = 'Remove Trans_Jag1';
    end 
    load([title_str,'.mat'])
    cell_id = [115,109,95];
% cell_id = randperm(parameter.N,3)
Plot_Gene_Dynamic(sol, parameter, cell_id, [0,1500],0)
end

%%
colors = lines(4);
figure('position',[10,800,300,300])
for caseID = 1:4
    switch caseID
        case 1
            title_str = 'Remove Cis_Dll1';
        case 2
            title_str = 'Remove Trans_Dll1';
        case 3
            title_str = 'Remove Cis_Jag1';
        case 4
            title_str = 'Remove Trans_Jag1';
    end 
    load([title_str,'.mat'])
%     Estimate_Hes1_AP_Ptf1a_Mean(sol, parameter,0);
    subplot(2,2,caseID)
    plot(sol.Statistic(:,3),sol.Statistic(:,1),'o','MarkerEdgeColor',[0.2,0.2,0.2],'MarkerFaceColor',colors(caseID,:))
    hold on
    set(gca,'box','off','YDir','normal','linewidth',1.5,'fontsize',14,'TickLength',[0.02,0.02],'TickDir','out')
    if caseID == 1
       xlim([0,12])
       ylim([0,6])
    end
end