function dydt = cell_rearrange0(t,y,interaction_M,b, Vm)
% calculate dr/dt for each cell
% y(1:N)--> x, y(N+1:2*N)-->y, y(2*N+1:3*N)-->z
N = size(interaction_M,1); % cell number
dydt = zeros(3*N,1);

cell_loc = [y(1:N,1),y(N+1:2*N,1),y(2*N+1:3*N,1)]; 
R_ij = pdist2(cell_loc,cell_loc);
E = exp(-R_ij)-1/b*exp(-R_ij/b);
E(R_ij>0) = E(R_ij>0)./R_ij(R_ij>0);

X = repmat(y(1:N,1),1,N);
X0 = X'-X;
w = -interaction_M.*X0.*E;
dydt(1:N,1) = Vm*sum(w,2);


X = repmat(y(N+1:2*N,1),1,N);
X0 = X'-X;
w = -interaction_M.*X0.*E;
dydt(N+1:2*N,1) = Vm*sum(w,2);

X = repmat(y(2*N+1:3*N,1),1,N);
X0 = X'-X;
w = -interaction_M.*X0.*E;
dydt(2*N+1:3*N,1) = Vm*sum(w,2);
end

