%
% Code for construction of the static 3D structure with 400 cells.
%
%%
rng(0)
total_cell_number = 400;
parameter.N = total_cell_number;
% get stable cell positions
parameter.candidate_nei_num = 100;   % max num of neighbour
parameter.neighbor_threshold = 15;   % num threshold (not used)
parameter.b = 5;                     % strength of force
parameter.Vm = 1;                    % time scale for velocity

parameter.cell_center = rand(total_cell_number,3);
parameter.dt = 1;

iter_num = 100;
dis = zeros(iter_num,1);
for i = 1:iter_num
    center0 = parameter.cell_center;
    parameter = find_neighbors(parameter);% get parameter.interaction_M
    parameter = cell_rearrange(parameter);
    center1 = parameter.cell_center - center0;
    dis(i,1) = sum(sqrt(center1(:,1).^2+center1(:,2).^2+center1(:,3).^2));
end

% find the cells on the surface and get parameter.interaction_M
parameter.out_or_not = zeros(parameter.N,1);
parameter = find_neighbors(parameter); 

% trim epithelial cells
parameter.All_cell_center = parameter.cell_center;
parameter.cell_center_M = parameter.cell_center(parameter.out_or_not==1,:); % Cell positions for Mesenchymal cells
parameter.interaction_M_M = parameter.interaction_M; % Interaction matrix for all the cells
parameter.cell_center = parameter.cell_center(parameter.out_or_not==0,:);
parameter.N = size(parameter.cell_center,1);
parameter.interaction_M = parameter.interaction_M(parameter.out_or_not==0,parameter.out_or_not==0);

% save results
% save R0_Dis dis
% save R0_Parameter parameter
%% Plot Cell Positions
% load('R0_Dis.mat')
% load('R0_Parameter.mat')
close all
Msize = 300;
figure('position',[100,800,500,300])
clear h
h(1) = subplot(1,2,1);
plot(dis,'color',[0.7,0.3,0.3],'linewidth',2)
box off
set(gca,'fontsize',14,'TickDir','out','TickLength',[0.02,0.02],'linewidth',1);
xlabel('Iteration');
ylabel('Sum of position changes')

h(2) = subplot(1,2,2);
scatter3(parameter.cell_center(:,1),parameter.cell_center(:,2),parameter.cell_center(:,3),...
    Msize,repmat([0.8,0.6,0.3],parameter.N,1),'filled','linewidth',0.5)
alpha 0.4
hold on
scatter3(parameter.cell_center(:,1),parameter.cell_center(:,2),parameter.cell_center(:,3),...
    Msize,repmat([0.7,0.5,0.3],parameter.N,1),'linewidth',2)

scatter3(parameter.cell_center_M(:,1),parameter.cell_center_M(:,2),parameter.cell_center_M(:,3),...
    Msize,[0.5,0.5,0.5],'filled','linewidth',2)
alpha 0.4
scatter3(parameter.cell_center_M(:,1),parameter.cell_center_M(:,2),parameter.cell_center_M(:,3),...
    Msize,[0.5,0.5,0.5],'linewidth',2)
set(gca,'fontsize',12,'TickDir','out','TickLength',[0.02,0.02],'linewidth',1);
xlabel('x');ylabel('y');zlabel('z');
set(gca,'xtick',-10:10:10,'ytick',-10:10:10,'ztick',-10:10:10)
zlim([-3,3])
title(' z \in [-3, 3]','FontWeight','normal')
view(0,90)
h(1).Position = [0.16,0.23,0.70,0.69];
h(2).Position = [0.57,0.42,0.26,0.43];

